<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Connect Stages</h1>
        <form method="post" action="<?php echo e(route('admin.stages.storeConnectedStages')); ?>">
            <?php echo csrf_field(); ?>
            <label for="parent_stage_id">Parent Stage:</label>
            <select name="parent_stage_id" required>
                <?php $__currentLoopData = $parentStages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentStage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($parentStage->id); ?>"><?php echo e($parentStage->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <label for="child_stage_names">Child Stage Names:</label>
            <select name="parent_stage_id" required multiple>
                <?php $__currentLoopData = $parentStages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentStage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($parentStage->id); ?>"><?php echo e($parentStage->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <button type="submit">Connect Stages</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lms_bbc-main\resources\views/admin/stages/connect.blade.php ENDPATH**/ ?>