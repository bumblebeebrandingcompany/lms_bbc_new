<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row mb-2">
        <div class="col-sm-6">
            <h2>
                <?php echo app('translator')->get('messages.documents'); ?>
            </h2>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card card-primary card-outline">
                <?php if(auth()->user()->is_superadmin): ?>
                    <div class="card-header">
                        <a class="btn btn-success float-right" href="<?php echo e(route('admin.documents.create')); ?>">
                            <?php echo e(trans('global.add')); ?> <?php echo e(trans('messages.document')); ?>

                        </a>
                    </div>
                <?php endif; ?>
               <div class="card-body">
                    <div class="row mb-5">
                        <div class="col-md-3">
                            <label for="project_id">
                                <?php echo app('translator')->get('messages.projects'); ?>
                            </label>
                            <select class="search form-control" id="project_id">
                                <option value><?php echo e(trans('global.all')); ?></option>
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($id); ?>"><?php echo e($title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <table class=" table table-bordered table-striped table-hover ajaxTable datatable datatable-documents">
                        <thead>
                            <tr>
                                <th width="10">
                                </th>
                                <th>
                                    <?php echo app('translator')->get('messages.title'); ?>
                                </th>
                                <th>
                                    <?php echo app('translator')->get('messages.project'); ?>
                                </th>
                                <th>
                                    <?php echo e(trans('messages.added_by')); ?>

                                </th>
                                <th>
                                    <?php echo e(trans('messages.created_at')); ?>

                                </th>
                                <th>
                                    &nbsp;
                                </th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
        let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
        <?php if(auth()->user()->is_superadmin): ?>
            let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>';
            let deleteButton = {
                text: deleteButtonTrans,
                url: "<?php echo e(route('admin.documents.massDestroy')); ?>",
                className: 'btn-danger',
                action: function (e, dt, node, config) {
                var ids = $.map(dt.rows({ selected: true }).data(), function (entry) {
                    return entry.id
                });

                if (ids.length === 0) {
                    alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')
                    return
                }

                if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
                    $.ajax({
                    headers: {'x-csrf-token': _token},
                    method: 'POST',
                    url: config.url,
                    data: { ids: ids, _method: 'DELETE' }})
                    .done(function () { location.reload() })
                }
                }
            }
            dtButtons.push(deleteButton)
        <?php endif; ?>

        let dtOverrideGlobals = {
            buttons: dtButtons,
            processing: true,
            serverSide: true,
            retrieve: true,
            aaSorting: [],
            ajax: {
                url: "<?php echo e(route('admin.documents.index')); ?>",
                data: function (d) {
                    d.project_id = $("#project_id").val();
                }
            },
            columns: [
                { data: 'placeholder', name: 'placeholder' },
                { data: 'title', name: 'title' },
                { data: 'project_name', name: 'projects.name' },
                { data: 'added_by', name: 'users.name' },
                { data: 'created_at', name: 'documents.created_at' },
                { data: 'actions', name: '<?php echo e(trans('global.actions')); ?>' }
            ],
            orderCellsTop: true,
            order: [[ 4, 'desc' ]],
            pageLength: 50,
        };

        let table = $('.datatable-documents').DataTable(dtOverrideGlobals);
        $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
            $($.fn.dataTable.tables(true)).DataTable()
            .columns.adjust();
        });
  
        let visibleColumnsIndexes = null;

        $(document).on('change', '#project_id', function () {
            table.ajax.reload();
        });

        table.on('column-visibility.dt', function(e, settings, column, state) {
            visibleColumnsIndexes = []
            table.columns(":visible").every(function(colIdx) {
                visibleColumnsIndexes.push(colIdx);
            });
        })
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lms_bbc-main\resources\views/admin/documents/index.blade.php ENDPATH**/ ?>