
<div class="row">
    <div class="col-md-5">
        <?php if($project->essential_fields): ?>
            <?php $__currentLoopData = json_decode($project->essential_fields, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $essentialField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($essentialField['enabled']) && $essentialField['enabled'] === "1"): ?>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="required">
                                <?php echo app('translator')->get('messages.key'); ?>
                            </label>
                            <input type="text" name="api[<?php echo e($webhook_key); ?>][request_body][<?php echo e($rb_key); ?>][key][<?php echo e($key); ?>]" value="<?php echo e($essentialField['name']); ?>" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="required">
                                <?php echo app('translator')->get('messages.value'); ?>
                            </label>
                            <input type="text" name="api[<?php echo e($webhook_key); ?>][request_body][<?php echo e($rb_key); ?>][value][<?php echo e($key); ?>]" value="<?php echo e($essentialField['value']); ?>" class="form-control">
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="form-group">
                <label class="required">
                    <?php echo app('translator')->get('messages.value'); ?>
                </label>
                <input type="text" name="essential_fields[description]" value="" class="form-control">
                <div class="col-md-1 mt-auto mb-auto">
                    <div class="form-group">
                        <button type="button" class="btn btn-danger btn-sm float-right delete_request_body_row">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>


<div class="row">
    <div class="col-md-5">
        <?php if($project->custom_fields): ?>
            <?php $__currentLoopData = json_decode($project->custom_fields, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($customField['enabled']) && $customField['enabled'] === "1"): ?>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="required">
                                <?php echo app('translator')->get('messages.key'); ?>
                            </label>
                            <input type="text" name="api[<?php echo e($webhook_key); ?>][request_body][<?php echo e($rb_key); ?>][key]" value="<?php echo e($customField['name']); ?>" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="required">
                                <?php echo app('translator')->get('messages.value'); ?>
                            </label>
                            <input type="text" name="api[<?php echo e($webhook_key); ?>][request_body][<?php echo e($rb_key); ?>][value][]" value="<?php echo e($customField['value']); ?>" class="form-control">
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="form-group">
                <label class="required">
                    <?php echo app('translator')->get('messages.value'); ?>
                </label>
                <input type="text" name="custom_fields[description]" value="" class="form-control">
                <div class="col-md-1 mt-auto mb-auto">
                    <div class="form-group">
                        <button type="button" class="btn btn-danger btn-sm float-right delete_request_body_row">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>



<div class="row">
    <div class="col-md-5">
        <?php if($project->sales_fields): ?>
            <?php $__currentLoopData = json_decode($project->sales_fields, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $salesField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($salesField['enabled']) && $salesField['enabled'] === "1"): ?>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="required">
                                <?php echo app('translator')->get('messages.key'); ?>
                            </label>
                            <input type="text" name="api[<?php echo e($webhook_key); ?>][request_body][<?php echo e($rb_key); ?>][key]" value="<?php echo e($salesField['name']); ?>" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="required">
                                <?php echo app('translator')->get('messages.value'); ?>
                            </label>
                            <input type="text" name="api[<?php echo e($webhook_key); ?>][request_body][<?php echo e($rb_key); ?>][value][]" value="<?php echo e($salesField['value']); ?>" class="form-control">
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="form-group">
                <label class="required">
                    <?php echo app('translator')->get('messages.value'); ?>
                </label>
                <input type="text" name="sales_fields[description]" value="" class="form-control">
                <div class="col-md-1 mt-auto mb-auto">
                    <div class="form-group">
                        <button type="button" class="btn btn-danger btn-sm float-right delete_request_body_row">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>



<div class="row">
    <div class="col-md-5">
        <?php if($project->essential_fields): ?>
            <?php $__currentLoopData = json_decode($project->system_fields, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $systemField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($systemField['enabled']) && $systemField['enabled'] === "1"): ?>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="required">
                                <?php echo app('translator')->get('messages.key'); ?>
                            </label>
                            <input type="text" name="api[<?php echo e($webhook_key); ?>][request_body][<?php echo e($rb_key); ?>][key]" value="<?php echo e($systemField['name']); ?>" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="required">
                                <?php echo app('translator')->get('messages.value'); ?>
                            </label>
                            <input type="text" name="api[<?php echo e($webhook_key); ?>][request_body][<?php echo e($rb_key); ?>][value][]" value="<?php echo e($systemField['value']); ?>" class="form-control">
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="form-group">
                <label class="required">
                    <?php echo app('translator')->get('messages.value'); ?>
                </label>
                <input type="text" name="system_fields[description]" value="" class="form-control">
                <div class="col-md-1 mt-auto mb-auto">
                    <div class="form-group">
                        <button type="button" class="btn btn-danger btn-sm float-right delete_request_body_row">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\lms_bbc-main\resources\views/admin/projects/partials/request_body_input.blade.php ENDPATH**/ ?>