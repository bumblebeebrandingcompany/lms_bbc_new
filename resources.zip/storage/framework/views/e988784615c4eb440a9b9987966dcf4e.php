<style>
    .saved-note {
        background-color: #f2f2f2;
        /* Gray background color */
        padding: 10px;
        /* Add some padding to make it visually appealing */
        margin-bottom: 10px;
        /* Add some space between containers */
    }
</style>
<div class="form-group">
    <p>Notes for Lead ID: <?php echo e($lead->id); ?></p>
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addNoteModal">
        Add Note
    </button>
<br>
<br>
<div class="modal fade" id="addNoteModal" tabindex="-1" role="dialog" aria-labelledby="addNoteModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addNoteModalLabel">Add Note</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="POST" action="<?php echo e(route('admin.notes.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="lead_id" value="<?php echo e($lead->id); ?>">
                    <h3 class="card-title"> Notes for Lead ID: <?php echo e($lead->id); ?></h3>
                    <br>

                    <div class="form-group">
                        <label for="noteContent">Note Content</label>
                        <textarea class="form-control <?php echo e($errors->has('note_text') ? 'is-invalid' : ''); ?>" name="note_text" id="note_text"
                         rows="4" required><?php echo e(old('note_text')); ?></textarea>
                    </div>
            </div>
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save Note</button>
            </div>
        </div>
    </div>
</div>
<div class="form-group">
    <div id="savedNotesContainer" class="saved-notes-container">
        <!-- Display saved notes here -->
        <?php $__currentLoopData = $note; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="saved-note">
                <label for="note_text" class="saved-note-label">Note:</label>
                <div class="saved-note-text"><?php echo e($note->note_text); ?></div>

                <label for="created at" class="saved-note-label">Date:</label>
                <div class="saved-created_at"><?php echo e($note->created_at); ?></div>


                
                
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

</form>
</div>
<?php /**PATH C:\laragon\www\lms_bbc-main\resources\views/admin/leads/partials/notes.blade.php ENDPATH**/ ?>