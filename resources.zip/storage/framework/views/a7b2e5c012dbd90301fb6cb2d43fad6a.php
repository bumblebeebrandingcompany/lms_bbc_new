<?php $__env->startSection('content'); ?>
<div class="row mb-2">
   <div class="col-sm-12">
        <h2>
            <?php echo app('translator')->get('messages.configure_webhook_details'); ?>
            <small>
                <strong>Project:</strong>
                <span class="text-primary"><?php echo e($project->name); ?></span>
            </small>
        </h2>
   </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-6">
                        <h3 class="card-title">
                            <?php echo e(trans('messages.send_webhook')); ?>

                        </h3>
                    </div>
                    <div class="col-md-6">
                        <a class="btn btn-default float-right" href="<?php echo e(route('admin.projects.index')); ?>">
                            <i class="fas fa-chevron-left"></i>
                            <?php echo e(trans('global.back_to_list')); ?>

                        </a>
                    </div>
                </div>
            </div>
            <form action="<?php echo e(route('admin.project.outgoing.webhook.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php
                    $db_fields = \App\Models\Lead::DEFAULT_WEBHOOK_FIELDS;
                    $tags = !empty($project->webhook_fields) ? array_unique(array_merge($project->webhook_fields, $db_fields)) : $db_fields;
                ?>
                <div class="card-body">
                    <input type="hidden" name="project_id" value="<?php echo e($project->id); ?>" id="project_id">
                    <h4>
                        <?php echo e(trans('messages.outgoing_webhook')); ?>

                    </h4>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group outgoing_api">
                                <?php
                                    $apis = $project->outgoing_apis ?? [];
                                    $api_webhook_key = 0;
                                ?>
                                <?php $__empty_1 = true; $__currentLoopData = $apis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $api): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php
                                        $api_webhook_key = $key;
                                    ?>
                                    <?php if ($__env->exists('admin.projects.partials.api_card', ['key' => $key, 'api' => $api, 'tags' => $tags])) echo $__env->make('admin.projects.partials.api_card', ['key' => $key, 'api' => $api, 'tags' => $tags], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php for($i = 0; $i<=0 ; $i++): ?>
                                        <?php
                                            $api_webhook_key = $i;
                                        ?>
                                        <?php if ($__env->exists('admin.projects.partials.api_card', ['key' => $i, 'api' => [], 'tags' => $tags])) echo $__env->make('admin.projects.partials.api_card', ['key' => $i, 'api' => [], 'tags' => $tags], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endfor; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <button type="button" class="btn btn-outline-primary add_outgoing_api"
                                data-api_webhook_key="<?php echo e($api_webhook_key); ?>">
                                <?php echo app('translator')->get('messages.add_outgoing_webhook'); ?>
                            </button>
                            <button type="submit" class="btn btn-primary float-right">
                                Save
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(function() {
        $(document).on('click', '.add_outgoing_api', function() {
            let key = $(this).attr('data-api_webhook_key');
            let project_id = $("#project_id").val();
            $.ajax({
                method:"GET",
                url: "<?php echo e(route('admin.projects.webhook.html')); ?>",
                data: {
                    type: 'api',
                    key: parseInt(key)+1,
                    project_id: project_id
                },
                dataType: "html",
                success: function(response) {
                    $("div.outgoing_api").append(response);
                    $(".add_outgoing_api").attr('data-api_webhook_key', +key + 1);
                    $(".select-tags").select2();
                }
            });
        });

        $(document).on('click', '.delete_api_webhook, .delete_webhook', function() {
            if(confirm('Do you want to remove?')) {
                $(this).closest('.card').remove();
            }
        });

        $(document).on('click', '.add_request_body_row', function() {
            let webhook_key = $(this).attr('data-webhook_key');
            let request_body_div = $(this).closest('.card').find('.request_body');
            let btn = $(this);
            let project_id = $("#project_id").val();
            let rb_key = $(this).attr('data-rb_key');
            $.ajax({
                method:"GET",
                url: "<?php echo e(route('admin.get.req.body.row.html')); ?>",
                data: {
                    project_id: project_id,
                    webhook_key: webhook_key,
                    rb_key: parseInt(rb_key)+1
                },
                dataType: "html",
                success: function(response) {
                    request_body_div.append(response);
                    btn.attr('data-rb_key', +rb_key + 1);
                    $(".select-tags").select2();
                }
            });
        });

        $(document).on('click', '.delete_request_body_row', function() {
            if(confirm('Do you want to remove?')) {
                $(this).closest('.row').remove();
            }
        });

        $(document).on('click', '.test_webhook', function() {
            let card_id = $(this).attr('data-card_id');
            let data = {};
            $(`#${card_id} .input`).each(function() {
                data[$(this).attr('name')] = $(this).val();
            });
            $.ajax({
                method:"POST",
                url:"<?php echo e(route('admin.projects.test.webhook')); ?>",
                data:data,
                dataType: "JSON",
                success: function(response) {
                    if(response.msg) {
                        alert(decodeURIComponent(response.msg));
                    }
                }
            })
        });

        $(document).on('click', '.add_constant_row', function() {
            let webhook_key = $(this).attr('data-webhook_key');
            let api_constant_div = $(this).closest('.card').find('.api_constant');
            let btn = $(this);
            let constant_key = $(this).attr('data-constant_key');
            $.ajax({
                method:"GET",
                url: "<?php echo e(route('admin.get.api.constant.row.html')); ?>",
                data: {
                    webhook_key: webhook_key,
                    constant_key: parseInt(constant_key)+1
                },
                dataType: "html",
                success: function(response) {
                    api_constant_div.append(response);
                    btn.attr('data-constant_key', +constant_key + 1);
                }
            });
        });

        $(document).on('click', '.delete_constant_row', function() {
            if(confirm('Do you want to remove?')) {
                $(this).closest('.row').remove();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lms_bbc-main\resources\views/admin/projects/webhook.blade.php ENDPATH**/ ?>