<?php $__env->startSection('styles'); ?>
<style>
    #filter-container {
        min-height: auto !important;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content_header'); ?>
<div class="container-fluid">
    <?php if ($__env->exists('admin.leads.partials.header')) echo $__env->make('admin.leads.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if($lead_view == 'kanban'): ?>
    <?php if ($__env->exists('admin.leads.partials.kanban.kanban')) echo $__env->make('admin.leads.partials.kanban.kanban', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
        <?php if ($__env->exists('admin.leads.partials.common_lead_js')) echo $__env->make('admin.leads.partials.common_lead_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.kanban', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lms_bbc-main\resources\views/admin/leads/kanban_index.blade.php ENDPATH**/ ?>