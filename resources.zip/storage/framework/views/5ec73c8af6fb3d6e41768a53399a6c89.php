<?php if(count($documents) > 0): ?>
    <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card card-primary card-outline">
            <div class="card-header" id="document_<?php echo e($index); ?>">
            <h5 class="card-title w-100 mb-0">
                <button class="btn btn-link faq_question" data-toggle="collapse" 
                    data-target="#doc_acc_collapse_<?php echo e($index); ?>" aria-expanded="true" aria-controls="doc_acc_collapse_<?php echo e($index); ?>">
                    <?php echo e($document->title); ?>

                </button>
            </h5>
            </div>
            <div id="doc_acc_collapse_<?php echo e($index); ?>" class="collapse <?php if($index == 0): ?> show <?php endif; ?>" aria-labelledby="document_<?php echo e($index); ?>" data-parent="#document_accordion">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12 faq_answer">
                            <?php echo $document->details; ?>

                        </div>
                        <div class="col-md-12 mt-3">
                            <label for="note_<?php echo e($index); ?>">
                                <?php echo app('translator')->get('messages.note'); ?>
                            </label>
                            <textarea name="note" id="note_<?php echo e($index); ?>" rows="2" class="form-control"></textarea>
                            <button type="button" class="btn btn-outline-primary send_doc_to_lead mt-2"
                                data-href="<?php echo e(route('admin.share.lead.doc', ['lead_id' => $lead->id, 'doc_id' => $document->id])); ?>">
                                <?php echo app('translator')->get('messages.send_to_lead'); ?>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <div class="callout callout-warning">
        <h5>No, documents found.</h5>
    </div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\lms_bbc-main\resources\views/admin/leads/partials/document_card.blade.php ENDPATH**/ ?>