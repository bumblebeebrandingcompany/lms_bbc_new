<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="row mb-2">
        <div class="col-sm-12">
            <h2>
                <?php echo app('translator')->get('messages.document_logs'); ?>
            </h2>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card card-primary card-outline">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>
                                                <?php echo app('translator')->get('messages.lead'); ?>
                                            </th>
                                            <th>
                                                <?php echo app('translator')->get('messages.document'); ?>
                                            </th>
                                            <th>
                                                <?php echo app('translator')->get('messages.note'); ?>
                                            </th>
                                            <th>
                                                <?php echo app('translator')->get('messages.status'); ?>
                                            </th>
                                            <th>
                                                <?php echo app('translator')->get('messages.sent_by'); ?>
                                            </th>
                                            <th>
                                                <?php echo app('translator')->get('messages.sent_at'); ?>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                                <td>
                                                    <?php if(!empty($activity->lead)): ?>
                                                        <strong><?php echo e($activity->lead->name ?? ''); ?></strong>
                                                    <?php endif; ?>
                                                    <?php if(!empty($activity->lead->ref_num)): ?>
                                                        (<code><small><?php echo e($activity->lead->ref_num ?? ''); ?></small></code>)
                                                    <?php endif; ?>
                                                    <?php if(!empty($activity->lead) && (!empty($activity->lead->email) || !empty($activity->lead->additional_email))): ?>
                                                        <br>
                                                        <?php echo e($activity->lead->email ?? ''); ?>

                                                        <?php if(!empty($activity->lead->additional_email)): ?>
                                                            <?php if(!empty($activity->lead->email)): ?>
                                                                <?php echo e('/'); ?>

                                                            <?php endif; ?>
                                                            <?php echo e($activity->lead->additional_email); ?>

                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </td>
                                                <?php
                                                    $webhook_data = $activity->webhook_data ?? [];
                                                    if(!empty($webhook_data['sent_by'])) {
                                                        $user = \App\Models\User::find($webhook_data['sent_by']);
                                                        $webhook_data['sent_by'] = !empty($user) ? $user->name : '';
                                                    }
                                                    if(!empty($webhook_data['document_id'])) {
                                                        $document = \App\Models\Document::find($webhook_data['document_id']);
                                                        $webhook_data['document'] = !empty($document) ? $document->title : '';
                                                        if(!empty($document)) {
                                                            $util = new App\Utils\Util();
                                                            $url = $util->generateGuestDocumentViewUrl($document->id);
                                                            $webhook_data['document'] .= '<br><br><a class="btn btn-sm btn-outline-dark" target="_blank" href="'.$url.'">View </a>';
                                                        }
                                                        unset($webhook_data['document_id']);
                                                    }
                                                    if(!empty($webhook_data['document_id'])) {
                                                        $document = \App\Models\Document::find($webhook_data['document_id']);
                                                        $webhook_data['document'] = !empty($document) ? $document->title : '';
                                                        unset($webhook_data['document_id']);
                                                    }
                                                ?>
                                                <td>
                                                    <?php echo $webhook_data['document'] ?? ''; ?>

                                                </td>
                                                <td><?php echo nl2br($webhook_data['note'] ?? ''); ?></td>
                                                <td>
                                                    <?php echo e(ucfirst($webhook_data['status'] ?? '')); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($webhook_data['sent_by'] ?? ''); ?>

                                                </td>
                                                <td>
                                                    <?php if(!empty($webhook_data['datetime'])): ?>
                                                        <?php echo e(\Carbon\Carbon::createFromTimestamp(strtotime($webhook_data['datetime']))->format('M d Y h:i A')); ?>

                                                    <?php endif; ?>
                                                </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="6" class="text-center">
                                                    No log found
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <?php if(!empty($activities->links())): ?>
                            <div class="col-md-12 text-right mb-3">
                                <?php echo e($activities->links()); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lms_bbc-main\resources\views/admin/documents/log.blade.php ENDPATH**/ ?>