<table class=" table table-bordered table-striped table-hover ajaxTable datatable datatable-Lead">
    <thead>
        <tr>
            <th width="10">

            </th>
            <th>
                <?php echo app('translator')->get('messages.ref_num'); ?>
            </th>
            <th>
                <?php echo app('translator')->get('messages.name'); ?>
            </th>
            <th>
                <?php echo app('translator')->get('messages.email'); ?>
            </th>
            <th>
                <?php echo app('translator')->get('messages.phone'); ?>
            </th>
            <th>
                <?php echo app('translator')->get('messages.alternate_phone'); ?>
            </th>
            <!-- <th>
                <?php echo app('translator')->get('messages.status'); ?>
            </th>
            <th>
                <?php echo app('translator')->get('messages.sell_do_date'); ?>
            </th>
            <th>
                <?php echo app('translator')->get('messages.sell_do_time'); ?>
            </th>
            <th>
                <?php echo app('translator')->get('messages.sell_do_lead_id'); ?>
            </th> -->
            <th>
                <?php echo e(trans('cruds.lead.fields.project')); ?>

            </th>
            <th>
                <?php echo e(trans('cruds.lead.fields.campaign')); ?>

            </th>
            <th>
                <?php echo e(trans('messages.source')); ?>

            </th>
            <th>
                <?php echo e(trans('messages.added_by')); ?>

            </th>
            <th>
                <?php echo e(trans('messages.created_at')); ?>

            </th>
            <th>
                <?php echo e(trans('messages.updated_at')); ?>

            </th>
            <th>
                &nbsp;
            </th>
        </tr>
    </thead>
</table><?php /**PATH C:\xampp\htdocs\lms_bbc-main\resources\views/admin/leads/partials/lead_table/lead_table.blade.php ENDPATH**/ ?>