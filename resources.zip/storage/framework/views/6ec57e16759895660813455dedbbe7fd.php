<?php $__env->startSection('content'); ?>
    <h1>
        Lead Follow Up List</h1>
    <div class="card">

        <div class="card-header">
            <h3 class="card-title">Lead Follow-Up Table</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="campaign_name">Select Campaign Name</label>
                        <select id="campaign_name" name="campaign_name" class="form-control">
                            <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->campaign_name): ?>
                                    <!-- Check if representative_name is not null or empty -->
                                    <option value="<?php echo e($item->campaign_name); ?>"><?php echo e($item->campaign_name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="staffMember">Select Staff Member</label>
                        <select id="staffMember" name="staffMember" class="form-control">
                            <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->representative_name): ?>
                                    <!-- Check if representative_name is not null or empty -->
                                    <?php if(trim($item->representative_name) !== ''): ?>
                                        <!-- Check if representative_name is not empty after trimming -->
                                        <option value="<?php echo e($item->representative_name); ?>"><?php echo e($item->representative_name); ?>

                                        </option>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="form-group">
                        <label for="start_date"><?php echo e(trans('cruds.project.fields.start_date')); ?></label>
                        <input class="form-control date <?php echo e($errors->has('start_date') ? 'is-invalid' : ''); ?>" type="text"
                            name="start_date" id="start_date" value="<?php echo e(old('start_date')); ?>">
                        <?php if($errors->has('start_date')): ?>
                            <span class="text-danger"><?php echo e($errors->first('start_date')); ?></span>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.project.fields.start_date_helper')); ?></span>
                    </div>
                </div>
            </div>

            <table class="table">
                <thead>
                    <tr>
                        <th>Reference Number</th>
                        <th>Campaign Name</th>
                        <th>Follow-Up Date</th>
                        <th>Follow-Up Time</th>
                        <th>Follow-Up By</th>
                        <th>notes</th>
                        

                        <!-- Add more table headers for other lead follow-up properties -->
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $followUps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $followUp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php $__currentLoopData = $lead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($leads->id === $followUp->lead_id): ?>
                                        <?php echo e($leads->ref_num); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php $__currentLoopData = $lead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($leads->id === $followUp->lead_id): ?>
                                        <?php echo e($leads->campaign->campaign_name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php $__currentLoopData = $lead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($leads->id === $followUp->lead_id): ?>
                                        <?php echo e($followUp->follow_up_date); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php $__currentLoopData = $lead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($leads->id === $followUp->lead_id): ?>
                                        <?php echo e($followUp->follow_up_time); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            
                            
                            <td>
                                <?php echo e($followUp->users->representative_name); ?>

                            </td>
                            <td>
                                <?php $__currentLoopData = $lead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($leads->id === $followUp->lead_id): ?>
                                        <?php echo e($followUp->notes); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('scripts'); ?>
            <script>
                function confirmDelete() {
                    return confirm('<?php echo e(trans('global.areYouSure')); ?>');
                }
            </script>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lms_bbc-main\resources\views/admin/leads/followup/index.blade.php ENDPATH**/ ?>