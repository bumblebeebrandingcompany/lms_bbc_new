<div class="card card-primary card-outline">
    <div class="card-body box-profile">
        <div class="text-center">
            <?php
                $avatar = 'https://ui-avatars.com/api/?background=random&font-size=0.7&name='.$lead->name;
            ?>
            <img class="profile-user-img img-fluid img-circle" src="<?php echo e($avatar); ?>"
            alt="<?php echo e($lead->name ?? ''); ?>">
        </div>
        <h3 class="profile-username text-center">
            <?php echo e($lead->name ?? ''); ?>

        </h3>
        <ul class="list-group list-group-unbordered mb-3">
            <li class="list-group-item">
                <b><?php echo e(trans('messages.ref_num')); ?></b> 
                <a class="float-right"><?php echo e($lead->ref_num); ?></a>
            </li>
            <!-- <li class="list-group-item">
                <b><?php echo app('translator')->get('messages.sell_do_lead_id'); ?></b>
                <a class="float-right">
                    <?php echo $lead->sell_do_lead_id ?? ''; ?>

                </a>
            </li> -->
            <li class="list-group-item">
                <b> <?php echo app('translator')->get('messages.email'); ?></b>
                <a class="float-right">
                    <?php if(auth()->user()->is_channel_partner_manager && !empty($lead->email)): ?>
                        <?php echo e(maskEmail($lead->email)); ?>

                    <?php else: ?>
                        <?php echo e($lead->email ?? ''); ?>

                    <?php endif; ?>
                </a>
            </li>
            <li class="list-group-item">
                <b><?php echo app('translator')->get('messages.additional_email_key'); ?></b>
                <a class="float-right">
                    <?php if(auth()->user()->is_channel_partner_manager && !empty($lead->additional_email)): ?>
                        <?php echo e(maskEmail($lead->additional_email)); ?>

                    <?php else: ?>
                        <?php echo e($lead->additional_email ?? ''); ?>

                    <?php endif; ?>
                </a>
            </li>
            <li class="list-group-item">
                <b><?php echo app('translator')->get('messages.phone'); ?></b>
                <a class="float-right">
                    <?php if(auth()->user()->is_channel_partner_manager && !empty($lead->phone)): ?>
                        <?php echo e(maskNumber($lead->phone)); ?>

                    <?php else: ?>
                        <?php echo e($lead->phone ?? ''); ?>

                    <?php endif; ?>
                </a>
            </li>
            <li class="list-group-item">
                <b><?php echo app('translator')->get('messages.secondary_phone_key'); ?></b>
                <a class="float-right">
                    <?php if(auth()->user()->is_channel_partner_manager && !empty($lead->secondary_phone)): ?>
                        <?php echo e(maskNumber($lead->secondary_phone)); ?>

                    <?php else: ?>
                        <?php echo e($lead->secondary_phone ?? ''); ?>

                    <?php endif; ?>
                </a>
            </li>
            <li class="list-group-item">
                <b><?php echo e(trans('cruds.lead.fields.project')); ?></b>
                <a class="float-right">
                    <?php echo e($lead->project->name ?? ''); ?>

                </a>
            </li>
            <li class="list-group-item">
                <b><?php echo e(trans('cruds.lead.fields.campaign')); ?></b>
                <a class="float-right">
                    <?php echo e($lead->campaign->campaign_name ?? ''); ?>

                </a>
            </li>
            <li class="list-group-item">
                <b><?php echo e(trans('messages.source')); ?></b>
                <a class="float-right">
                    <?php echo e($lead->source->name ?? ''); ?>

                </a>
            </li>
            <?php
                $lead_info = $lead->lead_info;
                if (
                    !empty($lead->source) && 
                    !empty($lead->source->name_key) && 
                    isset($lead_info[$lead->source->name_key]) &&
                    !empty($lead_info[$lead->source->name_key])
                ) {
                    unset($lead_info[$lead->source->name_key]);
                }

                if (
                    !empty($lead->source) && 
                    !empty($lead->source->email_key) && 
                    isset($lead_info[$lead->source->email_key]) &&
                    !empty($lead_info[$lead->source->email_key])
                ) {
                    unset($lead_info[$lead->source->email_key]);
                }

                if (
                    !empty($lead->source) && 
                    !empty($lead->source->phone_key) &&
                    isset($lead_info[$lead->source->phone_key]) &&
                    !empty($lead_info[$lead->source->phone_key])
                ) {
                    unset($lead_info[$lead->source->phone_key]);
                }

                if (
                    !empty($lead->source) && 
                    !empty($lead->source->additional_email_key) && 
                    isset($lead_info[$lead->source->additional_email_key]) &&
                    !empty($lead_info[$lead->source->additional_email_key])
                ) {
                    unset($lead_info[$lead->source->additional_email_key]);
                }

                if (
                    !empty($lead->source) && 
                    !empty($lead->source->secondary_phone_key) &&
                    isset($lead_info[$lead->source->secondary_phone_key]) &&
                    !empty($lead_info[$lead->source->secondary_phone_key])
                ) {
                    unset($lead_info[$lead->source->secondary_phone_key]);
                }
            ?>
            <?php $__currentLoopData = $lead_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                    <b><?php echo $key; ?></b>
                    <a class="float-right">
                        <?php echo $value; ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- <li class="list-group-item">
                <b><?php echo app('translator')->get('messages.sell_do_created_date'); ?></b>
                <a class="float-right">
                    <?php if(!empty($lead->sell_do_lead_created_at)): ?>
                        <?php echo e(\Carbon\Carbon::createFromTimestamp(strtotime($lead->sell_do_lead_created_at))->format('M d Y h:i A')); ?>

                    <?php endif; ?>
                </a>
            </li> -->
            <!-- <li class="list-group-item">
                <b><?php echo app('translator')->get('messages.sell_do_status'); ?></b>
                <a class="float-right">
                    <?php echo $lead->sell_do_status ?? ''; ?>

                </a>
            </li> -->
            <!-- <li class="list-group-item">
                <b><?php echo app('translator')->get('messages.sell_do_stage'); ?></b>
                <a class="float-right">
                    <?php echo $lead->sell_do_stage ?? ''; ?>

                </a>
            </li> -->
            <li class="list-group-item">
                <b><?php echo app('translator')->get('messages.customer_comments'); ?></b>
                <a class="float-right">
                    <?php echo $lead->comments ?? ''; ?>

                </a>
            </li>
            <li class="list-group-item">
                <b><?php echo app('translator')->get('messages.cp_comments'); ?></b>
                <a class="float-right">
                    <?php echo $lead->cp_comments ?? ''; ?>

                </a>
            </li>
            <li class="list-group-item">
                <b><?php echo app('translator')->get('messages.added_by'); ?></b>
                <a class="float-right">
                    <?php echo e($lead->createdBy ? $lead->createdBy->name : ''); ?>

                </a>
            </li>
        </ul>
    </div>
</div><?php /**PATH C:\xampp\htdocs\lms_bbc-main\resources\views/admin/leads/partials/user_details.blade.php ENDPATH**/ ?>