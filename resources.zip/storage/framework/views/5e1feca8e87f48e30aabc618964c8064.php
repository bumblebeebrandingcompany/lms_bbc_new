<div class="card border-secondary mb-4" data-key="<?php echo e($key); ?>" id="card_<?php echo e($key); ?>">
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label class="required">
                        <?php echo e(trans('messages.name')); ?>

                    </label>
                    <input type="text" placeholder="<?php echo e(trans('messages.name')); ?>" value="<?php echo e($api['name'] ?? ''); ?>" name="api[<?php echo e($key); ?>][name]" class="form-control input">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label class="required">
                        <?php echo e(trans('messages.url_to_send_webhook')); ?>

                    </label>
                    <input type="url" placeholder="<?php echo e(trans('messages.url_to_send_webhook')); ?>" value="<?php echo e($api['url'] ?? ''); ?>" name="api[<?php echo e($key); ?>][url]" class="form-control input" required>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>
                        <?php echo e(trans('messages.secret_key')); ?>

                        <i class="fas fa-info-circle" data-html="true" data-toggle="tooltip" title="<?php echo e(trans('messages.12_char_random_str')); ?>"></i>
                    </label>
                    <input type="text" placeholder="<?php echo e(trans('messages.secret_key')); ?>" value="<?php echo e($api['secret_key'] ?? ''); ?>" name="api[<?php echo e($key); ?>][secret_key]" class="form-control input">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label class="required">
                        <?php echo e(trans('messages.method')); ?>

                    </label>
                    <select name="api[<?php echo e($key); ?>][method]" class="form-control input" required>
                        <option value="get"
                            <?php if(
                                isset($api['method']) &&
                                !empty($api['method']) &&
                                $api['method'] == 'get'
                            ): ?>
                                selected
                            <?php endif; ?>>
                            GET
                        </option>
                        <option value="post"
                            <?php if(
                                isset($api['method']) &&
                                !empty($api['method']) &&
                                $api['method'] == 'post'
                            ): ?>
                                selected
                            <?php endif; ?>>
                            POST
                        </option>
                    </select>
                </div>
            </div>
        </div>
        <!-- <div class="row">
            <div class="col-md-12">
                <div class="form-group">
                    <label>
                        <?php echo e(trans('messages.headers')); ?>

                    </label>
                    <textarea  class="form-control" name="api[<?php echo e($key); ?>][headers]" rows="1"><?php echo e($api['headers'] ?? ''); ?></textarea>
                    <small class="form-text text-muted">
                        <?php echo e(trans('messages.headers_help_text')); ?> <br>
                        Ex: {"header-1" : "header 1 Value", "header-2" : "header 2 Value", "header3" : "header 3 Value"}
                    </small>
                </div>
            </div>
        </div> -->
        <div class="row mb-3">
            <div class="col-md-12">
                <div class="form-group api_constant">
                    <label>
                        <?php echo e(trans('messages.constants')); ?>

                        <i class="fas fa-info-circle" data-html="true" data-toggle="tooltip" title="<?php echo e(trans('messages.constants_help_text')); ?>"></i>
                    </label>
                    <?php if(!empty($api['constants'])): ?>
                        <?php $__currentLoopData = $api['constants']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $constant_key = $loop->index;
                            ?>
                            <?php if ($__env->exists('admin.projects.partials.constants', [
                                'webhook_key' => $key,
                                'constant_key' => $constant_key,
                                'constant' => $value
                            ])) echo $__env->make('admin.projects.partials.constants', [
                                'webhook_key' => $key,
                                'constant_key' => $constant_key,
                                'constant' => $value
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <?php if ($__env->exists('admin.projects.partials.constants', [
                            'webhook_key' => $key,
                            'constant_key' => 0,
                            'constant' => []
                        ])) echo $__env->make('admin.projects.partials.constants', [
                            'webhook_key' => $key,
                            'constant_key' => 0,
                            'constant' => []
                        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                </div>
                <button type="button" class="btn btn-primary btn-sm add_constant_row"
                    data-constant_key="<?php echo e($constant_key ?? 0); ?>" data-webhook_key="<?php echo e($key); ?>">
                    <?php echo app('translator')->get('messages.add_constant'); ?>
                </button>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="form-group request_body">
                    <label>
                        <?php echo e(trans('messages.request_body')); ?>

                        <i class="fas fa-info-circle" data-html="true" data-toggle="tooltip" title="<?php echo e(trans('messages.request_body_help_text')); ?>"></i>
                    </label>
                    <div class="row">
                        <div class="col-md-12 mb-3 bg-info p-2">
                            <small>
                            Fields with predefined prefix are initial fields present in the system.<br/>
                            <b>predefined_source_name:</b> It will take the source name. But if lead is added by channel partner it'll take channel partner name as source
                            </small>
                        </div>
                    </div>
                    <?php
                        $rb_key = 0;
                    ?>
                    <?php if(!empty($api['request_body'])): ?>
                        <?php $__currentLoopData = $api['request_body']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $rb_key = $loop->index;
                            ?>
                            <?php if ($__env->exists('admin.projects.partials.request_body_input', [
                                'webhook_key' => $key,
                                'rb_key' => $rb_key,
                                // 'tags=' => $tags,
                                'customFields' => $value
                            ])) echo $__env->make('admin.projects.partials.request_body_input', [
                                'webhook_key' => $key,
                                'rb_key' => $rb_key,
                                // 'tags=' => $tags,
                                'customFields' => $value
                            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <?php if ($__env->exists('admin.projects.partials.request_body_input', [
                            'webhook_key' => $key,
                            'rb_key' => $rb_key,
                            // 'tags' => $tags,
                            'customFields' => []
                        ])) echo $__env->make('admin.projects.partials.request_body_input', [
                            'webhook_key' => $key,
                            'rb_key' => $rb_key,
                            // 'tags' => $tags,
                            'customFields' => []
                        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">

                <button type="button" class="btn btn-outline-secondary btn-sm test_webhook"
                    data-card_id="card_<?php echo e($key); ?>">
                    <?php echo app('translator')->get('messages.test_webhook'); ?>
                </button>
                <button type="button" class="btn btn-outline-danger btn-sm float-right delete_api_webhook mr-2">
                    <i class="fas fa-trash-alt"></i> <?php echo app('translator')->get('messages.remove_webhook'); ?>
                </button>
            </div>
        </div>
    </div>
</div>


<?php /**PATH C:\xampp\htdocs\lms_bbc-main\resources\views/admin/projects/partials/api_card.blade.php ENDPATH**/ ?>