<div class="card border-secondary" data-key="<?php echo e($key); ?>">
    <div class="card-body">
        <div class="row">
            <div class="col-md-7">
                <div class="form-group">
                    <label>
                        <?php echo e(trans('messages.url_to_send_webhook')); ?> *
                    </label>
                    <input type="url" placeholder="<?php echo e(trans('messages.url_to_send_webhook')); ?>" value="<?php echo e($webhook['url'] ?? ''); ?>" name="webhook[<?php echo e($key); ?>][url]" class="form-control">
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label>
                        <?php echo e(trans('messages.secret_key')); ?>

                        <i class="fas fa-info-circle" data-html="true" data-toggle="tooltip" title="<?php echo e(trans('messages.12_char_random_str')); ?>"></i>
                    </label>
                    <input type="text" placeholder="<?php echo e(trans('messages.secret_key')); ?>" value="<?php echo e($webhook['secret_key'] ?? ''); ?>" name="webhook[<?php echo e($key); ?>][secret_key]" class="form-control">
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label>
                        <?php echo e(trans('messages.method')); ?> *
                    </label>
                    <select name="webhook[<?php echo e($key); ?>][method]" class="form-control">
                        <option value="get"
                            <?php if(
                                isset($webhook['method']) && 
                                !empty($webhook['method']) &&
                                $webhook['method'] == 'get'
                            ): ?>
                                selected
                            <?php endif; ?>>
                            GET
                        </option>
                        <option value="post"
                            <?php if(
                                isset($webhook['method']) && 
                                !empty($webhook['method']) &&
                                $webhook['method'] == 'post'
                            ): ?>
                                selected
                            <?php endif; ?>>
                            POST
                        </option>
                    </select>
                </div>
            </div>
        </div>
        <button type="button" class="btn btn-danger btn-sm float-right delete_webhook">
            <i class="fas fa-trash-alt"></i>
        </button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\lms_bbc-main\resources\views/admin/projects/partials/webhook_card.blade.php ENDPATH**/ ?>