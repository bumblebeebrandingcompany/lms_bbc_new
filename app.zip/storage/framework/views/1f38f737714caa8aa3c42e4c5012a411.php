<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label for="source_field1">
                <?php echo e(trans('messages.source_field', ['num' => 1])); ?>

            </label>
            <input class="form-control" type="text" name="source_field1" 
                id="source_field1" value="<?php echo e($source->source_field1 ?? old('source_field1')); ?>">
            <span class="help-block"><?php echo e(trans('messages.source_custom_field_help_text', ['num' => 1])); ?></span>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label for="source_field1_description">
                <?php echo e(trans('messages.source_field_description', ['num' => 1])); ?>

            </label>
            <input class="form-control" type="text" name="source_field1_description" 
                id="source_field1_description" value="<?php echo e($source->source_field1_description ?? old('source_field1_description')); ?>">
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label for="source_field2">
                <?php echo e(trans('messages.source_field', ['num' => 2])); ?>

            </label>
            <input class="form-control" type="text" name="source_field2" 
                id="source_field2" value="<?php echo e($source->source_field2 ?? old('source_field2')); ?>">
            <span class="help-block"><?php echo e(trans('messages.source_custom_field_help_text', ['num' => 2])); ?></span>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label for="source_field2_description">
                <?php echo e(trans('messages.source_field_description', ['num' => 2])); ?>

            </label>
            <input class="form-control" type="text" name="source_field2_description" 
                id="source_field2_description" value="<?php echo e($source->source_field2_description ?? old('source_field2_description')); ?>">
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label for="source_field3">
                <?php echo e(trans('messages.source_field', ['num' => 3])); ?>

            </label>
            <input class="form-control" type="text" name="source_field3" 
                id="source_field3" value="<?php echo e($source->source_field3 ?? old('source_field3')); ?>">
            <span class="help-block"><?php echo e(trans('messages.source_custom_field_help_text', ['num' => 3])); ?></span>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label for="source_field3_description">
                <?php echo e(trans('messages.source_field_description', ['num' => 3])); ?>

            </label>
            <input class="form-control" type="text" name="source_field3_description" 
                id="source_field3_description" value="<?php echo e($source->source_field3_description ?? old('source_field3_description')); ?>">
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="form-group">
            <label for="source_field4">
                <?php echo e(trans('messages.source_field', ['num' => 4])); ?>

            </label>
            <input class="form-control" type="text" name="source_field4" 
                id="source_field4" value="<?php echo e($source->source_field4 ?? old('source_field4')); ?>">
            <span class="help-block"><?php echo e(trans('messages.source_custom_field_help_text', ['num' => 4])); ?></span>
        </div>
    </div>

    <div class="col-md-6">
        <div class="form-group">
            <label for="source_field4_description">
                <?php echo e(trans('messages.source_field_description', ['num' => 4])); ?>

            </label>
            <input class="form-control" type="text" name="source_field4_description" 
                id="source_field4_description" value="<?php echo e($source->source_field4_description ?? old('source_field4_description')); ?>">
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\lms_bbc-main\resources\views/admin/sources/partials/custom_fields.blade.php ENDPATH**/ ?>