<div class="m-3">
    <div class="card">
        <?php if(auth()->user()->is_superadmin): ?>
            <div class="card-header">
                <a class="btn btn-success float-right" href="<?php echo e(route('admin.sources.create')); ?>">
                    <?php echo e(trans('global.add')); ?> <?php echo e(trans('cruds.source.title_singular')); ?>

                </a>
            </div>
        <?php endif; ?>
        <div class="card-body">
            <div class="table-responsive">
                <table class=" table table-bordered table-striped table-hover datatable datatable-campaignSources">
                    <thead>
                        <tr>
                            <th width="10">

                            </th>
                            <th>
                                <?php echo e(trans('cruds.source.fields.id')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.source.fields.project')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.source.fields.campaign')); ?>

                            </th>
                            <th>
                                <?php echo e(trans('cruds.source.fields.name')); ?>

                            </th>
                            <th>
                                &nbsp;
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-entry-id="<?php echo e($source->id); ?>">
                                <td>

                                </td>
                                <td>
                                    <?php echo e($source->id ?? ''); ?>

                                </td>
                                <td>
                                    <?php echo e($source->project->name ?? ''); ?>

                                </td>
                                <td>
                                    <?php echo e($source->campaign->campaign_name ?? ''); ?>

                                </td>
                                <td>
                                    <?php echo e($source->name ?? ''); ?>

                                </td>
                                <td>
                                    <?php if(auth()->user()->is_superadmin): ?>
                                        <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.sources.show', $source->id)); ?>">
                                            <?php echo e(trans('global.view')); ?>

                                        </a>
                                        <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.sources.edit', $source->id)); ?>">
                                            <?php echo e(trans('global.edit')); ?>

                                        </a>
                                        <a class="btn btn-xs btn-dark" href="<?php echo e(route('admin.sources.webhook', $source->id)); ?>">
                                            <?php echo e(trans('messages.webhook')); ?>

                                        </a>
                                        <form action="<?php echo e(route('admin.sources.destroy', $source->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                            <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->startSection('scripts'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>
<script>
    $(function () {
  let dtButtons = $.extend(true, [], $.fn.dataTable.defaults.buttons)
<?php if(auth()->user()->is_superadmin): ?>
  let deleteButtonTrans = '<?php echo e(trans('global.datatables.delete')); ?>'
  let deleteButton = {
    text: deleteButtonTrans,
    url: "<?php echo e(route('admin.sources.massDestroy')); ?>",
    className: 'btn-danger',
    action: function (e, dt, node, config) {
      var ids = $.map(dt.rows({ selected: true }).nodes(), function (entry) {
          return $(entry).data('entry-id')
      });

      if (ids.length === 0) {
        alert('<?php echo e(trans('global.datatables.zero_selected')); ?>')

        return
      }

      if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $.ajax({
          headers: {'x-csrf-token': _token},
          method: 'POST',
          url: config.url,
          data: { ids: ids, _method: 'DELETE' }})
          .done(function () { location.reload() })
      }
    }
  }
  dtButtons.push(deleteButton)
<?php endif; ?>

  $.extend(true, $.fn.dataTable.defaults, {
    orderCellsTop: true,
    order: [[ 1, 'desc' ]],
    pageLength: 100,
  });
  let table = $('.datatable-campaignSources:not(.ajaxTable)').DataTable({ buttons: dtButtons })
  $('a[data-toggle="tab"]').on('shown.bs.tab click', function(e){
      $($.fn.dataTable.tables(true)).DataTable()
          .columns.adjust();
  });
  
})

</script>
<?php $__env->stopSection(); ?><?php /**PATH C:\laragon\www\lms_bbc-main\resources\views/admin/campaigns/relationships/campaignSources.blade.php ENDPATH**/ ?>