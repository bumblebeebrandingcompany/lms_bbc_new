<?php $__env->startSection('content'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h2>
                <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.project.title_singular')); ?>

            </h2>
        </div>
    </div>
    <div class="card card-primary card-outline">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.projects.update', [$project->id])); ?>" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label class="required" for="name"><?php echo e(trans('cruds.project.fields.name')); ?></label>
                    <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name"
                        id="name" value="<?php echo e(old('name', $project->name)); ?>" required>
                    <?php if($errors->has('name')): ?>
                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.project.fields.name_helper')); ?></span>
                </div>
                <div class="form-group">
                    <label for="start_date"><?php echo e(trans('cruds.project.fields.start_date')); ?></label>
                    <input class="form-control date <?php echo e($errors->has('start_date') ? 'is-invalid' : ''); ?>" type="text"
                        name="start_date" id="start_date" value="<?php echo e(old('start_date', $project->start_date)); ?>">
                    <?php if($errors->has('start_date')): ?>
                        <span class="text-danger"><?php echo e($errors->first('start_date')); ?></span>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.project.fields.start_date_helper')); ?></span>
                </div>
                <div class="form-group">
                    <label for="end_date"><?php echo e(trans('cruds.project.fields.end_date')); ?></label>
                    <input class="form-control date <?php echo e($errors->has('end_date') ? 'is-invalid' : ''); ?>" type="text"
                        name="end_date" id="end_date" value="<?php echo e(old('end_date', $project->end_date)); ?>">
                    <?php if($errors->has('end_date')): ?>
                        <span class="text-danger"><?php echo e($errors->first('end_date')); ?></span>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.project.fields.end_date_helper')); ?></span>
                </div>
                <div class="form-group">
                    <label class="required" for="client_id"><?php echo e(trans('cruds.project.fields.client')); ?></label>
                    <select class="form-control select2 <?php echo e($errors->has('client') ? 'is-invalid' : ''); ?>" name="client_id"
                        id="client_id" required>
                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>"
                                <?php echo e((old('client_id') ? old('client_id') : $project->client->id ?? '') == $id ? 'selected' : ''); ?>>
                                <?php echo e($entry); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('client')): ?>
                        <span class="text-danger"><?php echo e($errors->first('client')); ?></span>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.project.fields.client_helper')); ?></span>
                </div>
                <div class="form-group">
                    <label for="location"><?php echo e(trans('cruds.project.fields.location')); ?></label>
                    <input class="form-control <?php echo e($errors->has('location') ? 'is-invalid' : ''); ?>" type="text"
                        name="location" id="location" value="<?php echo e(old('location', $project->location)); ?>">
                    <?php if($errors->has('location')): ?>
                        <span class="text-danger"><?php echo e($errors->first('location')); ?></span>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.project.fields.location_helper')); ?></span>
                </div>
                <div class="form-group">
                    <label for="description"><?php echo e(trans('cruds.project.fields.description')); ?></label>
                    <textarea class="form-control ckeditor <?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>" name="description"
                        id="description"><?php echo old('description', $project->description); ?></textarea>
                    <?php if($errors->has('description')): ?>
                        <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.project.fields.description_helper')); ?></span>
                </div>
                
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-6">
                            <label for="essential_fields"><?php echo e(trans('cruds.project.fields.essential')); ?></label>
                        </div>
                    </div>
                    <div id="essential-fields-container">
                        <?php if($project->essential_fields): ?>

                            <?php $__currentLoopData = $project->essential_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $essentialField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row mb-2">
                                    <div class="col-md-3">
                                        <label for="essential_fields"><?php echo e($essentialField['name_data']); ?></label>
                                        <input type="hidden" name="essential_fields[<?php echo e($key); ?>][name_data]" value="<?php echo e($essentialField['name_data']); ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <input class="form-control" type="text"
                                            name="essential_fields[<?php echo e($key); ?>][name_key]"
                                            value="<?php echo e($essentialField['name_key']); ?>" readonly>
                                    </div>
                                    <div class="col-md-3">
                                        <input class="form-control" type="text"
                                            name="essential_fields[<?php echo e($key); ?>][name_value]"
                                            value="<?php echo e($essentialField['name_value']); ?>" placeholder="Field Value" readonly>
                                    </div>
                                    <div class="col-md-1">
                                        <label class="switch">
                                            <input type="checkbox" name="essential_fields[<?php echo e($key); ?>][enabled]"
                                                value="1"
                                                <?php echo e(isset($essentialField['enabled']) && $essentialField['enabled'] === '1' ? 'checked' : ''); ?>>
                                            <span class="slider round"></span>
                                            <input type="hidden" name="essential_fields[<?php echo e($key); ?>][disabled]"
                                                value="0">
                                        </label>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>

                
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-6">
                            <label for="sales_fields"><?php echo e(trans('cruds.project.fields.sales')); ?></label>
                        </div>
                    </div>
                    <div id="sales-fields-container">
                        <?php if($project->sales_fields): ?>

                            <?php $__currentLoopData = $project->sales_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $salesField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row mb-2">
                                    <div class="col-md-3">
                                        <label for="sales_fields"><?php echo e($salesField['name_data']); ?></label>
                                        <input type="hidden" name="sales_fields[<?php echo e($key); ?>][name_data]" value="<?php echo e($salesField['name_data']); ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <input class="form-control" type="text"
                                            name="sales_fields[<?php echo e($key); ?>][name_key]"
                                            value="<?php echo e($salesField['name_key']); ?>" readonly>
                                    </div>
                                    <div class="col-md-3">
                                        <input class="form-control" type="text"
                                            name="sales_fields[<?php echo e($key); ?>][name_value]"
                                            value="<?php echo e($salesField['name_value']); ?>" readonly>
                                    </div>
                                    <div class="col-md-1">
                                        <label class="switch">
                                            <input type="checkbox" name="sales_fields[<?php echo e($key); ?>][enabled]"
                                                value="1"
                                                <?php echo e(isset($salesField['enabled']) && $salesField['enabled'] === '1' ? 'checked' : ''); ?>>
                                            <span class="slider round"></span>
                                            <input type="hidden" name="sales_fields[<?php echo e($key); ?>][disabled]"
                                                value="0">
                                        </label>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>

                
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-6">
                            <label for="system_fields"><?php echo e(trans('cruds.project.fields.system')); ?></label>
                        </div>
                    </div>
                    <div id="system-fields-container">
                        <?php if($project->system_fields): ?>

                            <?php $__currentLoopData = $project->system_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $systemField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row mb-2">
                                    <div class="col-md-3">
                                        <label for="system_fields"><?php echo e($systemField['name_data']); ?></label>
                                        <input type="hidden" name="system_fields[<?php echo e($key); ?>][name_data]" value="<?php echo e($systemField['name_data']); ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <input class="form-control" type="text"
                                            name="system_fields[<?php echo e($key); ?>][name_key]"
                                            value="<?php echo e($systemField['name_key']); ?>" readonly>
                                    </div>
                                    <div class="col-md-3">
                                        <input class="form-control" type="text"
                                            name="system_fields[<?php echo e($key); ?>][name_value]"
                                            value="<?php echo e($systemField['name_value']); ?>" readonly>
                                    </div>
                                    <div class="col-md-1">
                                        <label class="switch">
                                            <input type="checkbox" name="system_fields[<?php echo e($key); ?>][enabled]"
                                                value="1"
                                                <?php echo e(isset($systemField['enabled']) && $systemField['enabled'] === '1' ? 'checked' : ''); ?>>
                                            <span class="slider round"></span>
                                            <input type="hidden" name="system_fields[<?php echo e($key); ?>][disabled]"
                                                value="0">
                                        </label>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>

                
                <div class="form-group">
                    <div class="row">
                        <div class="col-md-6">
                            <label for="custom_fields"><?php echo e(trans('cruds.project.fields.custom')); ?></label>
                        </div>
                        <div class="col-md-6 text-right">
                            <button type="button" id="add-custom-field" class="btn btn-primary">Add Field</button>
                        </div>
                    </div>
                    <div id="custom-fields-container">
                        <?php if($project->custom_fields): ?>

                            <?php $__currentLoopData = $project->custom_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row mb-2">
                                    <div class="col-md-3">
                                        <label for="custom_fields"><?php echo e($customField['name_data']); ?></label>
                                        <input type="hidden" name="custom_fields[<?php echo e($key); ?>][name_data]" value="<?php echo e($customField['name_data']); ?>">
                                    </div>
                                    <div class="col-md-3">
                                        <input class="form-control" type="text"
                                            name="custom_fields[<?php echo e($key); ?>][name_key]"
                                            value="<?php echo e($customField['name_key']); ?>" placeholder="Field Value">
                                    </div>
                                    <div class="col-md-3">
                                        <input class="form-control" type="text"
                                            name="custom_fields[<?php echo e($key); ?>][name_value]"
                                            value="<?php echo e($customField['name_value']); ?>" placeholder="Field Value">
                                    </div>
                                    <div class="col-md-1">
                                        <label class="switch">
                                            <input type="checkbox" name="custom_fields[<?php echo e($key); ?>][enabled]"
                                                value="1"
                                                <?php echo e(isset($customField['enabled']) && $customField['enabled'] === '1' ? 'checked' : ''); ?>>
                                            <span class="slider round"></span>
                                            <input type="hidden" name="custom_fields[<?php echo e($key); ?>][disabled]"
                                                value="0">
                                        </label>
                                    </div>
                                    <div class="col-md-1">
                                        <button type="button" class="btn btn-danger remove-field">Remove</button>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="form-group text-end">
                    <input type="hidden" id="sales-fields-json" name="sales_fields_json" value="">
                    <button class="btn btn-danger" type="submit">
                        <?php echo e(trans('global.save')); ?>

                    </button>
                </div>
        </div>
        </form>
    </div>
    </div>

    </form>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            // Initialize an empty object to store essential fields
            const essentialFields = {};

            // Form submission event
            $('#essential-fields-form').on('submit', function(event) {
                event.preventDefault(); // Prevent the default form submission

                // Collect and format essential fields as an array of objects
                const essentialFieldsArray = [];

                $('div.row.mb-2').each(function() {
                    const nameData = $(this).find('input[name="essential_fields[name_data][]"]')
                        .val();
                    const nameKey = $(this).find('input[name="essential_fields[name_key][]"]')
                .val();
                    const nameValue = $(this).find('input[name="essential_fields[name_value][]"]')
                        .val();
                    const enabled = $(this).find('input[name="essential_fields[enabled][]"]').prop(
                        'checked') ? 1 : 0;

                    essentialFieldsArray.push({
                        name_data: nameData,
                        name_key: nameKey,
                        name_value: nameValue,
                        enabled: enabled,
                    }, );
                }, );

                essentialFields['essential_fields'] = essentialFieldsArray;

                $('#essential-fields-json').val(JSON.stringify(essentialFields));
            });
        }, );
    </script>


    
    <script>
        $(document).ready(function() {
            let fieldCounter =
                <?php echo e(isset($project) && is_array($project->custom_fields) ? count($project->custom_fields) : 0); ?>;
            const customFields = {};

            $('#add-custom-field').on('click', function() {
                fieldCounter++;

                const customFieldInput = `
            <div class="row mb-2">
                <div class="col-md-3">
                    <input class="form-control" type="text" name="custom_fields[${fieldCounter}][name_data]" placeholder="Field Name">
                </div>
                <div class="col-md-3">
                    <input class="form-control" type="text" name="custom_fields[${fieldCounter}][name_key] placeholder="Field Value">
                </div>
                <div class="col-md-3">
                    <input class="form-control" type="text" name="custom_fields[${fieldCounter}][name_value]" placeholder="Field Value">
                </div>
                <div class="col-md-1">
                    <label class="switch">
                        <input type="checkbox" name="custom_fields[${fieldCounter}][enabled]" value="1">
                        <span class="slider round"></span>
                        <input type="hidden" name="custom_fields[${fieldCounter}][disabled]" value="0">
                    </label>
                </div>

                <div class="col-md-1">
                    <button type="button" class="btn btn-danger remove-field">Remove</button>
                </div>
            </div>`;
                $('#custom-fields-container').append(customFieldInput);
            });

            // Remove Field button click event
            $('#custom-fields-container').on('click', '.remove-field', function() {
                $(this).parent().parent().remove();
            });

            // Form submission event
            $('form').on('submit', function() {
                // Collect and format custom fields as JSON
                const customFieldsArray = [];
                $('#custom-fields-container input[name^="custom_fields"]').each(function() {
                    const fieldData = $(this).attr('name').split('[');
                    const fieldIndex = fieldData[1];
                    const fieldName = fieldData[2].split(']')[0];
                    const fieldValue = $(this).val();
                    const fieldDataValue = $(`input[name="custom_fields[${fieldIndex}][data]"]`)
                        .val();
                    const isEnabled = $(`input[name="custom_fields[${fieldIndex}][enabled]"]`).prop(
                        'checked');
                    customFieldsArray.push({
                        name_key: fieldName,
                        nmae_value: fieldValue,
                        name_data: fieldDataValue,
                        enabled: isEnabled,
                    });
                });

                customFields['custom_fields'] = customFieldsArray;
                $('#custom-fields-json').val(JSON.stringify(customFields)); // Serialize as JSON
            });
        });
    </script>

    
    <script>
        $(document).ready(function() {
            const salesFields = [];
            // Form submission event
            $('form').on('submit', function() {
                // Form submission event
                $('#sales-fields-form').on('submit', function(event) {
                    event.preventDefault(); // Prevent the default form submission

                    // Collect and format sales fields as an array of objects
                    const salesFields = [];

                    $('div.row.mb-2').each(function() {
                        const nameKey = $(this).find(
                                'input[name="sales_fields[name_key][]"]')
                            .val();
                        const nameData = $(this).find(
                                'input[name="sales_fields[name_data][]"]')
                            .val();
                        const nameValue = $(this).find(
                                'input[name="sales_fields[name_value][]"]')
                            .val();
                        const enabled = $(this).find(
                                'input[name="sales_fields[enabled][]"]').prop('checked') ?
                            1 : 0;

                        salesFields.push({
                            name_data: nameData,
                            name_key: nameKey,
                            name_value: nameValue,
                            enabled: enabled,
                        });
                    });
                });
            });

            salesFields['sales_fields'] = salesFieldsArray;
            $('#sales-fields-json').val(JSON.stringify(salesFields)); // Serialize as JSON
        });
    </script>


    
    <script>
        $(document).ready(function() {
            const systemFields = {};
            $('form').on('submit', function() {
                // Form submission event
                $('#system-fields-form').on('submit', function(event) {
                    event.preventDefault();

                    const systemFields = [];

                    $('div.row.mb-2').each(function() {
                        const nameData = $(this).find(
                            'input[name="system_fields[name_data][]"]')
                        const nameKey = $(this).find(
                                'input[name="system_fields[name_key][]"]')
                            .val();
                        const nameValue = $(this).find(
                                'input[name="system_fields[name_value][]"]')
                            .val();
                        const enabled = $(this).find(
                            'input[name="system_fields[enabled][]"]').prop(
                            'checked') ? 1 : 0;

                        systemFields.push({
                            name_data: nameData,
                            name_key: nameKey,
                            name_value: nameValue,
                            enabled: enabled,
                        });
                    });
                });
            });

            systemFields['system_fields'] = essentialFieldsArray;
            $('#system-fields-json').val(JSON.stringify(essentialFields)); // Serialize as JSON

        });
    </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            function SimpleUploadAdapter(editor) {
                editor.plugins.get('FileRepository').createUploadAdapter = function(loader) {
                    return {
                        upload: function() {
                            return loader.file
                                .then(function(file) {
                                    return new Promise(function(resolve, reject) {
                                        // Init request
                                        var xhr = new XMLHttpRequest();
                                        xhr.open('POST',
                                            '<?php echo e(route('admin.projects.storeCKEditorImages')); ?>',
                                            true);
                                        xhr.setRequestHeader('x-csrf-token', window._token);
                                        xhr.setRequestHeader('Accept', 'application/json');
                                        xhr.responseType = 'json';

                                        // Init listeners
                                        var genericErrorText =
                                            `Couldn't upload file: ${ file.name }.`;
                                        xhr.addEventListener('error', function() {
                                            reject(genericErrorText)
                                        });
                                        xhr.addEventListener('abort', function() {
                                            reject()
                                        });
                                        xhr.addEventListener('load', function() {
                                            var response = xhr.response;

                                            if (!response || xhr.status !== 201) {
                                                return reject(response && response
                                                    .message ?
                                                    `${genericErrorText}\n${xhr.status} ${response.message}` :
                                                    `${genericErrorText}\n ${xhr.status} ${xhr.statusText}`
                                                );
                                            }

                                            $('form').append(
                                                '<input type="hidden" name="ck-media[]" value="' +
                                                response.id + '">');

                                            resolve({
                                                default: response.url
                                            });
                                        });

                                        if (xhr.upload) {
                                            xhr.upload.addEventListener('progress', function(
                                                e) {
                                                if (e.lengthComputable) {
                                                    loader.uploadTotal = e.total;
                                                    loader.uploaded = e.loaded;
                                                }
                                            });
                                        }

                                        // Send request
                                        var data = new FormData();
                                        data.append('upload', file);
                                        data.append('crud_id', '<?php echo e($project->id ?? 0); ?>');
                                        xhr.send(data);
                                    });
                                })
                        }
                    };
                }
            }

            var allEditors = document.querySelectorAll('.ckeditor');
            for (var i = 0; i < allEditors.length; ++i) {
                ClassicEditor.create(
                    allEditors[i], {
                        extraPlugins: [SimpleUploadAdapter]
                    }
                );
            }
        });
    </script>
<?php $__env->stopSection(); ?>

ChatGPT

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lms_bbc-main\resources\views/admin/projects/edit.blade.php ENDPATH**/ ?>