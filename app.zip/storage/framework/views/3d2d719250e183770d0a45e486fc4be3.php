<?php $__env->startSection('content'); ?>
<div class="row mb-2">
   <div class="col-sm-12">
        <h2>
            <?php echo e(trans('cruds.campaign.title')); ?> <span class="text-primary"><?php echo e($campaign->campaign_name); ?></span>
        </h2>
   </div>
</div>
<div class="row">
    <div class="col-md-4">
<div class="card card-primary card-outline">
    <div class="card-header">
        <a class="btn btn-default float-right" href="<?php echo e(route('admin.campaigns.index')); ?>">
            <i class="fas fa-chevron-left"></i>
            <?php echo e(trans('global.back_to_list')); ?>

        </a>
    </div>
    <div class="card-body">
        <div class="form-group">
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.campaign.fields.campaign_name')); ?>

                        </th>
                        <td>
                            <?php echo e($campaign->campaign_name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.campaign.fields.start_date')); ?>

                        </th>
                        <td>
                            <?php echo e($campaign->start_date); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.campaign.fields.end_date')); ?>

                        </th>
                        <td>
                            <?php echo e($campaign->end_date); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.campaign.fields.project')); ?>

                        </th>
                        <td>
                            <?php echo e($campaign->project->name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.campaign.fields.agency')); ?>

                        </th>
                        <td>
                            <?php echo e($campaign->agency->name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.campaign.fields.created_at')); ?>

                        </th>
                        <td>
                            <?php echo e($campaign->created_at); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.campaign.fields.updated_at')); ?>

                        </th>
                        <td>
                            <?php echo e($campaign->updated_at); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
<div class="col-md-8">
<div class="card card-primary card-outline">
    <div class="card-header">
        <?php echo e(trans('global.relatedData')); ?>

    </div>
    <ul class="nav nav-tabs" role="tablist" id="relationship-tabs">
        <li class="nav-item">
            <a class="nav-link active show" href="#campaign_leads" role="tab" data-toggle="tab">
                <?php echo e(trans('cruds.lead.title')); ?>

            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#campaign_sources" role="tab" data-toggle="tab">
                <?php echo e(trans('cruds.source.title')); ?>

            </a>
        </li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane active show" role="tabpanel" id="campaign_leads">
            <?php if ($__env->exists('admin.campaigns.relationships.campaignLeads', ['leads' => $campaign->campaignLeads])) echo $__env->make('admin.campaigns.relationships.campaignLeads', ['leads' => $campaign->campaignLeads], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="tab-pane" role="tabpanel" id="campaign_sources">
            <?php if ($__env->exists('admin.campaigns.relationships.campaignSources', ['sources' => $campaign->campaignSources])) echo $__env->make('admin.campaigns.relationships.campaignSources', ['sources' => $campaign->campaignSources], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lms_bbc-main\resources\views/admin/campaigns/show.blade.php ENDPATH**/ ?>