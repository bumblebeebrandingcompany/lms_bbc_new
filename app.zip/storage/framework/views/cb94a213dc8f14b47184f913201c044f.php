$(document).on('click', '#filter_leads', function() {
    let url = generateUrl("<?php echo e(route('admin.leads.index')); ?>", 'kanban');
    sessionStorage.setItem("leadListUrl", url);
    window.location = url;
});

$(document).on('click', '#send_bulk_outgoing_webhook', function() {
    let selected_ids = [];
    
    $(".lead_ids").each(function(){
        if($(this).is(":checked")) {
            selected_ids.push($(this).val());
        }
    });

    if (selected_ids.length === 0) {
        alert('<?php echo e(trans('messages.no_leads_selected')); ?>')
        return
    }

    sendOutgoingWebhooks(selected_ids);
});<?php /**PATH C:\laragon\www\lms_bbc-main\resources\views/admin/leads/partials/kanban/kanban_js.blade.php ENDPATH**/ ?>