if($(".date_range").length) {
    <?php if(
        isset($filters['start_date']) && 
        isset($filters['end_date']) && 
        !empty($filters['start_date']) && 
        !empty($filters['end_date'])
    ): ?>
        const startDate = moment("<?php echo e($filters['start_date']); ?>") || moment().subtract(29, 'days');
        const endDate = moment("<?php echo e($filters['end_date']); ?>") || moment();
    <?php else: ?>
        const startDate = moment().subtract(29, 'days');
        const endDate = moment();
    <?php endif; ?>
    $('.date_range').daterangepicker({
        startDate: startDate,
        endDate: endDate,
        ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        locale: {
            cancelLabel: 'Clear'
        }
    });
}

function sendOutgoingWebhooks(selected_ids) {
    if (confirm('<?php echo e(trans('global.areYouSure')); ?>')) {
        $("#send_bulk_outgoing_webhook").attr('disabled', true);
        $.ajax({
            method:"POST",
            url:"<?php echo e(route('admin.lead.send.mass.webhook')); ?>",
            data:{
                lead_ids:selected_ids
            },
            dataType: "JSON",
            success: function(response) {
                $("#send_bulk_outgoing_webhook").attr('disabled', false);
                if(response.msg) {
                    alert(decodeURIComponent(response.msg));
                }
            }
        })
    }
}

<?php if($lead_view == 'list'): ?>
    <?php if ($__env->exists('admin.leads.partials.lead_table.lead_table_js')) echo $__env->make('admin.leads.partials.lead_table.lead_table_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

/*
* filters
*/
function getProjectCampaigns() {
    $.ajax({
        method:"GET",
        url:"<?php echo e(route('admin.projects.campaigns')); ?>",
        data:{
            project_id:$("#project_id").val()
        },
        dataType: "html",
        success: function(response) {
            $(".campaigns_div").html(response);
        }
    });
}

function getProjectAdditionalFields() {
    $(".additional_columns_to_export_div").hide();
    $.ajax({
        method:"GET",
        url:"<?php echo e(route('admin.projects.additional.fields')); ?>",
        data:{
            project_id:$("#project_id").val()
        },
        dataType: "html",
        success: function(response) {
            $(".additional_columns_to_export_div").html(response).show();
            $("#additional_columns_to_export").select2({
                placeholder: "<?php echo e(trans('messages.please_select')); ?>"
            });
        }
    });
}

$(document).on('change', '#project_id', function() {
    getProjectCampaigns();
    getProjectAdditionalFields();
});

$(document).on('change', '#campaign_id', function() {
    $.ajax({
        method:"GET",
        url:"<?php echo e(route('admin.projects.campaign.sources')); ?>",
        data:{
            project_id:$("#project_id").val(),
            campaign_id:$("#campaign_id").val()
        },
        dataType: "html",
        success: function(response) {
            $(".sources_div").html(response);
        }
    });
});

function generateUrl(url, view='') {
    let filters = {};

    filters.project_id = $("#project_id").val();
    filters.campaign_id = $("#campaign_id").val();
    filters.leads_status = $("#leads_status").val();
    filters.no_lead_id = $("#no_lead_id").is(":checked");

    if($("#source_id").length) {
        filters.source = $("#source_id").val();
    }

    if($(".date_range").length) {
        filters.start_date = $('#added_on').data('daterangepicker').startDate.format('YYYY-MM-DD');
        filters.end_date = $('#added_on').data('daterangepicker').endDate.format('YYYY-MM-DD');
    }

    if($("#additional_columns_to_export").length) {
        filters.additional_columns = $("#additional_columns_to_export").val();
    }

    if(view) {
        filters.view = view;
    }

    const query = Object.keys(filters)
                    .map(key =>`${encodeURIComponent(key)}=${encodeURIComponent(filters[key])}`)
                    .join('&');

    if (query){
        url += `?${query}`;
    }

    return url;
}

$(document).on('click', '#download_excel', function(){
    let url = generateUrl("<?php echo e(route('admin.leads.export')); ?>");
    window.open(url,'_blank');
});

/*
* toggle data view
*/
$(document).on('change', '.toggle_view', function() {
    let view = $(this).val();
    if(view === 'kanban') {
        let url = generateUrl("<?php echo e(route('admin.leads.index')); ?>", view);
        sessionStorage.setItem("leadListUrl", url);
        window.location = url;
    } else {
        let url = "<?php echo e(route('admin.leads.index')); ?>?view=list";
        sessionStorage.setItem("leadListUrl", url);
        window.location = url;
    }
});

<?php if($lead_view == 'kanban'): ?>
    <?php if ($__env->exists('admin.leads.partials.kanban.kanban_js')) echo $__env->make('admin.leads.partials.kanban.kanban_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\lms_bbc-main\resources\views/admin/leads/partials/common_lead_js.blade.php ENDPATH**/ ?>