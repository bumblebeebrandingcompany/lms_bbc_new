<?php if(isset($viewGate) && $viewGate): ?>
    <a class="btn btn-xs btn-primary" href="<?php echo e(route('admin.' . $crudRoutePart . '.show', $row->id)); ?>">
        <?php echo e(trans('global.view')); ?>

    </a>
<?php endif; ?>
<?php if(isset($editGate) && $editGate): ?>
    <a class="btn btn-xs btn-info" href="<?php echo e(route('admin.' . $crudRoutePart . '.edit', $row->id)); ?>">
        <?php echo e(trans('global.edit')); ?>

    </a>
<?php endif; ?>
<?php if(isset($deleteGate) && $deleteGate): ?>
    <form action="<?php echo e(route('admin.' . $crudRoutePart . '.destroy', $row->id)); ?>" method="POST" onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');" style="display: inline-block;">
        <input type="hidden" name="_method" value="DELETE">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <input type="submit" class="btn btn-xs btn-danger" value="<?php echo e(trans('global.delete')); ?>">
    </form>
<?php endif; ?>
<?php if(isset($webhookSecretGate) && $webhookSecretGate): ?>
    <a class="btn btn-xs btn-dark" href="<?php echo e(route('admin.' . $crudRoutePart . '.webhook', $row->id)); ?>">
        <?php echo e(trans('messages.incoming_webhook')); ?>

    </a>
<?php endif; ?>
<?php if(isset($outgoingWebhookGate) && $outgoingWebhookGate): ?>
    <a class="btn btn-xs btn-dark" href="<?php echo e(route('admin.' . $crudRoutePart . '.webhook', $row->id)); ?>">
        <?php echo e(trans('messages.outgoing_webhook')); ?>

    </a>
<?php endif; ?>
<?php if(isset($passwordEditGate) && $passwordEditGate): ?>
    <button class="btn btn-xs btn-dark edit_password" data-href="<?php echo e(route('admin.' . $crudRoutePart . '.edit.password', $row->id)); ?>">
        <?php echo e(trans('messages.edit_password')); ?>

    </button>
<?php endif; ?>
<?php if(isset($docGuestViewGate) && $docGuestViewGate && !empty($docGuestViewUrl)): ?>
    <a class="btn btn-xs btn-dark" target="_blank" href="<?php echo e($docGuestViewUrl); ?>">
        <?php echo e(trans('messages.guest_view')); ?>

    </a>
<?php endif; ?><?php /**PATH C:\laragon\www\lms_bbc-main\resources\views/partials/datatablesActions.blade.php ENDPATH**/ ?>