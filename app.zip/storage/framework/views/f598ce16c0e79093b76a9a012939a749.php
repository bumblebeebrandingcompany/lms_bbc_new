<?php $__env->startSection('content'); ?>
<div class="row mb-2">
   <div class="col-sm-6">
        <h2>
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.agency.title_singular')); ?>

        </h2>
   </div>
</div>
<div class="card card-primary card-outline">
    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.agencies.update", [$agency->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="name"><?php echo e(trans('cruds.agency.fields.name')); ?></label>
                <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', $agency->name)); ?>" required>
                <?php if($errors->has('name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.agency.fields.name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="email"><?php echo e(trans('cruds.agency.fields.email')); ?></label>
                <input class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" type="email" name="email" id="email" value="<?php echo e(old('email', $agency->email)); ?>">
                <?php if($errors->has('email')): ?>
                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.agency.fields.email_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="contact_number_1"><?php echo e(trans('cruds.agency.fields.contact_number_1')); ?></label>
                <input class="form-control <?php echo e($errors->has('contact_number_1') ? 'is-invalid' : ''); ?>" type="text" name="contact_number_1" id="contact_number_1" value="<?php echo e(old('contact_number_1', $agency->contact_number_1)); ?>">
                <?php if($errors->has('contact_number_1')): ?>
                    <span class="text-danger"><?php echo e($errors->first('contact_number_1')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.agency.fields.contact_number_1_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lms_bbc-main\resources\views/admin/agencies/edit.blade.php ENDPATH**/ ?>