<div class="row">
    <div class="col-md-12" id="document_list">
        <div class="form-group row">
            <div class="col-md-6">
                <input type="text" name="search" class="form-control" placeholder="Search doc..." id="doc_search_input">
            </div>
            <div class="col-md-6">
                <select name="project_filter" id="project_filter"
                    class="form-select select2" style="width: 100%;">
                    <option value=""><?php echo app('translator')->get('messages.all'); ?></option>
                    <?php $__currentLoopData = $projects_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <div id="document_accordion" class="list">
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\lms_bbc-main\resources\views/admin/leads/partials/documents.blade.php ENDPATH**/ ?>