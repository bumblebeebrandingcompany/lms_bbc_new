<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://unpkg.com/pdfmake@0.1.18/build/pdfmake.min.js"></script>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Stages Popup</title>
<style>
    /* Styles for the popup */
    .popup {
        display: none;
        position: fixed;
        top: 30%;
        left: 50%;
        transform: translate(-50%, -50%);
        padding: 20px;
        background-color: #fff;
        border: 1px solid #ccc;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        z-index: 1000;
        width: 400px;
        /* Adjust the width as needed */
        height: 300px;
        /* Adjust the height as needed */
    }
</style>
<style>
    .popup {
        display: none;
    }

    .show {
        display: block;
    }
</style>
<style>
    .edit-field.error {
        background-color: #ffcccc;
        /* Change this to the desired shade of red */
    }
</style>
<div class="card card-primary card-outline">
    <div class="card-body box-profile">



        <div style="text-align: right;">
            <input type="hidden" name="lead_id" value="<?php echo e($lead->id); ?>">
            
            <div class="lead-item">
                <a href="<?php echo e(route('admin.leads.initiateCall', [$lead->id])); ?>" class="btn btn-primary"> <i
                        class="fas fa-phone fa-flip-horizontal"></i></a>
            </div>
        </div>
        <br>
        <button type="button" class="float-right edit-button">Edit</button>

        <div class="text-center">
            <?php
                $avatar = 'https://ui-avatars.com/api/?background=random&font-size=0.7&name=' . $lead->name;
            ?>
            <img class="profile-user-img img-fluid img-circle" src="<?php echo e($avatar); ?>" alt="<?php echo e($lead->name ?? ''); ?>">
        </div>
        <form method="POST" action="<?php echo e(route('admin.leads.update', [$lead->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <button type="submit" class="float-right save-button" style="display:none;">Save</button>
            <h3 class="profile-username text-center">
                <?php echo e($lead->name ?? ''); ?>

            </h3>
            <ul class="list-group list-group-unbordered mb-3">
                <li class="list-group-item">
                    <b><?php echo e(trans('messages.ref_num')); ?></b>
                    <a class="float-right"><?php echo e($lead->ref_num); ?></a>
                </li>
                <!-- <li class="list-group-item">
                <b><?php echo app('translator')->get('messages.sell_do_lead_id'); ?></b>
                <a class="float-right">
                    <?php echo $lead->sell_do_lead_id ?? ''; ?>

                </a>
            </li> -->
                <li class="list-group-item">
                    <b> <?php echo app('translator')->get('messages.email'); ?></b>
                    <a class="float-right">
                        <?php if(auth()->user()->is_channel_partner_manager && !empty($lead->email)): ?>
                            <?php echo e(maskEmail($lead->email)); ?>

                        <?php else: ?>
                            <?php echo e($lead->email ?? ''); ?>

                        <?php endif; ?>
                    </a>
                </li>
                
                <li class="list-group-item">
                    <b><?php echo e(trans('messages.additional_email_key')); ?></b>
                    <a class="float-right">
                        <span class="value-container">
                            <?php if(!$errors->has('additional_email')): ?>
                                <span class="display-value">
                                    <?php echo e($lead->additional_email); ?>

                                </span>
                            <?php endif; ?>
                            <input type="email" name="additional_email" class="edit-field"
                                placeholder="Enter additional mail"
                                style="<?php echo e($errors->has('additional_email') ? '' : 'display:none;'); ?>"
                                value="<?php echo e(old('additional_email')); ?>">
                        </span>
                        <?php $__errorArgs = ['additional_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger"><?php echo e($message); ?></div>
                            <script>
                                // Show save button when there is an error
                                $(document).ready(function() {
                                    $('.save-button').show();
                                });
                            </script>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </a>
                </li>
                <li class="list-group-item">
                    <b><?php echo app('translator')->get('messages.phone'); ?></b>
                    <a class="float-right">
                        <?php if(auth()->user()->is_channel_partner_manager && !empty($lead->phone)): ?>
                            <?php echo e(maskNumber($lead->phone)); ?>

                        <?php else: ?>
                            <?php echo e($lead->phone ?? ''); ?>

                        <?php endif; ?>
                    </a>
                </li>
                <li class="list-group-item">
                    <b><?php echo e(trans('messages.secondary_phone_key')); ?></b>
                    <a class="float-right">
                        <span class="value-container">
                            <span class="display-value"
                                style="<?php echo e($errors->has('secondary_phone') ? 'display:none;' : ''); ?>">
                                <?php echo e($lead->secondary_phone); ?>

                            </span>
                            <input type="phone" name="secondary_phone" class="edit-field"
                                placeholder="Enter Alternative Number"
                                style="<?php echo e($errors->has('secondary_phone') ? '' : 'display:none;'); ?>"
                                value="<?php echo e(old('secondary_phone')); ?>">
                            <?php $__errorArgs = ['secondary_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <script>
                                    // Show save button when there is an error
                                    $(document).ready(function() {
                                        $('.save-button').show();
                                    });
                                </script>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </a>
                </li>
                
                <li class="list-group-item">
                    <b><?php echo e(trans('cruds.lead.fields.project')); ?></b>
                    <a class="float-right">
                        <?php echo e($lead->project->name ?? ''); ?>

                    </a>
                </li>
                <li class="list-group-item">
                    <b><?php echo e(trans('cruds.lead.fields.campaign')); ?></b>
                    <a class="float-right">
                        <?php echo e($lead->campaign->campaign_name ?? ''); ?>

                    </a>
                </li>
                <li class="list-group-item">
                    <b><?php echo e(trans('messages.source')); ?></b>
                    <a class="float-right">
                        <?php echo e($lead->source->name ?? ''); ?>

                    </a>
                </li>

                <li class="list-group-item">
                    <b><?php echo e(trans('messages.intake_year')); ?></b>
                    <a class="float-right">
                        <span class="value-container">
                            <span class="display-value"><?php echo e($lead->intake_year); ?></span>

                            <select name="intake_year" class="edit-field"
                                style="<?php echo e($errors->has('intake_year') ? '' : 'display:none;'); ?>"
                                value="<?php echo e(old('intake_year')); ?>">
                                <?php if($lead->intake_year): ?>
                                    <option value="<?php echo e($lead->intake_year); ?>" selected><?php echo e($lead->intake_year); ?>

                                    </option>
                                <?php else: ?>
                                    <option value="" selected> Select Year</option>
                                <?php endif; ?>
                                <?php for($startYear = date('Y'); $startYear >= 2000; $startYear--): ?>
                                    <?php
                                        $endYear = $startYear + 1;
                                        $yearRange = $startYear . '-' . $endYear;
                                    ?>
                                    <option value="<?php echo e($yearRange); ?>"><?php echo e($yearRange); ?></option>
                                <?php endfor; ?>
                            </select>

                            <?php $__errorArgs = ['intake_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                
                                <script>
                                    $(document).ready(function() {
                                        $('.save-button').show();
                                    });
                                </script>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            
                        </span>
                    </a>
                </li>
                <li class="list-group-item">
                    <b><?php echo e(trans('messages.grade_enquired')); ?></b>
                    <a class="float-right">
                        <span class="value-container">
                            <span class="display-value"><?php echo e($lead->grade_enquired); ?></span>

                            <select name="grade_enquired" class="edit-field select2"
                                style="<?php echo e($errors->has('grade_enquired') ? '' : 'display:none;'); ?> ">

                                <?php if($lead->grade_enquired): ?>
                                    <option value="<?php echo e($lead->grade_enquired); ?>" selected><?php echo e($lead->grade_enquired); ?>

                                    </option>
                                <?php else: ?>
                                    <option value="" selected> Select Grade</option>
                                <?php endif; ?>

                                <?php for($i = -2; $i <= 12; $i++): ?>
                                    <?php
                                        if ($i == -2) {
                                            $grade = 'Pre-KG';
                                        } elseif ($i == -1) {
                                            $grade = 'LKG';
                                        } elseif ($i == 0) {
                                            $grade = 'UKG';
                                        } else {
                                            $grade = $i;
                                        }
                                    ?>
                                    <option value="<?php echo e($grade); ?>"
                                        <?php if(old('grade_enquired', $lead->grade_enquired) == $grade): ?> selected <?php endif; ?>>
                                        <?php echo e($grade); ?>

                                    </option>
                                <?php endfor; ?>
                            </select>
                            <?php $__errorArgs = ['grade_enquired'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <script>
                                    $(document).ready(function() {
                                        $('.save-button').show();
                                    });
                                </script>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </a>
                </li>
                </li>


                <li class="list-group-item">
                    <b><?php echo e(trans('messages.current_school')); ?></b>
                    <a class="float-right">
                        <span class="value-container">
                            <span class="display-value"
                                style="<?php echo e($errors->has('current_school') ? 'display:none;' : ''); ?>">
                                <?php echo e($lead->current_school); ?>

                            </span>
                            <input type="text" name="current_school" class="edit-field"
                                placeholder="Enter Current School"
                                style="<?php echo e($errors->has('current_school') ? '' : 'display:none;'); ?>"
                                value="<?php echo e(old('current_school')); ?>">
                            <?php $__errorArgs = ['current_school'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                
                                <script>
                                    $(document).ready(function() {
                                        $('.save-button').show();
                                    });
                                </script>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </a>
                </li>
                <li class="list-group-item">
                    <b>Stage</b>
                    <a class="float-right"><?php echo e($lead->parentStage->name ?? ''); ?></a>
                </li>
                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#stageModal">
                    View Stages
                </button>

                <div class="modal fade" id="stageModal" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Child Stages</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form method="POST" action="<?php echo e(route('admin.leads.update', [$lead->id])); ?>"
                                enctype="multipart/form-data">
                                <?php echo method_field('PUT'); ?>
                                <?php echo csrf_field(); ?>
                                <div class="modal-body">
                                    <p><b>Parent Stage:</b> <?php echo e($lead->parentStage->name ?? ' '); ?></p>
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label for="tag_id">Select Tag:</label>
                                            <select name="tag_id" id="tag_id" class="form-control">
                                                <option value="" selected disabled>Please Select</option>
                                                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <input type="hidden" name="parent_stage_id" id="selected_stage_id"
                                            value="<?php echo e($lead->parentstage->id ?? ''); ?>">

                                        <div class="form-group">
                                            <label for="child_stage_id">Select Child Stage:</label>
                                            <select name="parent_stage_id" id="child_stage_id" class="form-control" onchange="checkParentStageId(this)">
                                                <option value="" selected disabled>Please Select</option>
                                                
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary"
                                        data-dismiss="modal">Close</button>
                                    <button class="btn btn-primary float-right" type="submit">
                                        <?php echo e(trans('global.save')); ?>

                                    </button>
                                </div>
                            </form>
                        </div>
                        <form id="ResheduleFormId" method="POST" action="<?php echo e(route('admin.sitevisit.store')); ?>"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div id="rescheduleContent" style="display: none;">
                                <!-- Your follow-up content goes here -->
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="followUpModalLabel">Reschedule</h5>

                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="lead_id" value="<?php echo e($lead->id); ?>">

                                        <div class="form-group">
                                            <label type="select" for="user_id">clients</label>
                                            <select name="user_id" id="user_id"
                                                class="form-control<?php echo e($errors->has('user_id') ? ' is-invalid' : ''); ?>"
                                                rows="3" required><?php echo e(old('user_id')); ?>

                                                >
                                                <option value="" selected disabled>Please Select</option>
                                                <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $clients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $clients->clientUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($user->id); ?>"
                                                            <?php echo e(old('user_id') == $user->id ? 'selected' : ''); ?>>
                                                            <?php echo e($user->representative_name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="Date">Select Date </label>
                                            <input type="date"
                                                class="form-control datepicker <?php echo e($errors->has('form-control datepicker') ? 'is-invalid' : ''); ?>"
                                                name="follow_up_date" id="follow_up_date" rows="3"
                                                required><?php echo e(old('follow_up_date')); ?>

                                        </div>

                                        <div class="form-group">
                                            <label for="Time">select time </label>
                                            <input
                                                class="form-control timepicker <?php echo e($errors->has('form-control timepicker') ? 'is-invalid' : ''); ?>"
                                                name="follow_up_time" id="follow_up_time" rows="3"
                                                required><?php echo e(old('follow_up_time')); ?>

                                        </div>
                                        <div class="form-group">
                                            <label for="noteContent">Note Content</label>
                                            <textarea class="form-control <?php echo e($errors->has('notes') ? 'is-invalid' : ''); ?>" name="notes" id="notes"
                                                rows="4" required><?php echo e(old('notes')); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" onclick="togglePopup()">Close</button>
                                        <button class="btn btn-danger" type="submit">
                                            Save
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <form id="FollowupFormId" method="POST" action="<?php echo e(route('admin.followups.store')); ?>"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div id="followUpContent" style="display: none;">
                                <!-- Your follow-up content goes here -->
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="followUpModalLabel">Follow Up</h5>

                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="lead_id" value="<?php echo e($lead->id); ?>">

                                        <div class="form-group">
                                            <label type="select" for="user_id">clients</label>
                                            <select name="user_id" id="user_id"
                                                class="form-control<?php echo e($errors->has('user_id') ? ' is-invalid' : ''); ?>"
                                                rows="3" required><?php echo e(old('user_id')); ?>

                                                >
                                                <option value="" selected disabled>Please Select</option>
                                                <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $agency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $agency->agencyUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($user->id); ?>"
                                                            <?php echo e(old('user_id') == $user->id ? 'selected' : ''); ?>>
                                                            <?php echo e($user->representative_name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="Date">Select Date </label>
                                            <input type="date"
                                                class="form-control datepicker <?php echo e($errors->has('form-control datepicker') ? 'is-invalid' : ''); ?>"
                                                name="follow_up_date" id="follow_up_date" rows="3"
                                                required><?php echo e(old('follow_up_date')); ?>

                                        </div>

                                        <div class="form-group">
                                            <label for="Time">select time </label>
                                            <input
                                                class="form-control timepicker <?php echo e($errors->has('form-control timepicker') ? 'is-invalid' : ''); ?>"
                                                name="follow_up_time" id="follow_up_time" rows="3"
                                                required><?php echo e(old('follow_up_time')); ?>

                                        </div>
                                        <div class="form-group">
                                            <label for="noteContent">Note Content</label>
                                            <textarea class="form-control <?php echo e($errors->has('notes') ? 'is-invalid' : ''); ?>" name="notes" id="notes"
                                                rows="4" required><?php echo e(old('notes')); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" onclick="togglePopup()">Close</button>
                                        <button class="btn btn-danger" type="submit">
                                            Save
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                        <form id="SitevisitFormId" method="POST" action="<?php echo e(route('admin.sitevisit.store')); ?>"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div id="siteVisitContent" style="display: none;">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="followUpModalLabel">Site Visit</h5>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="lead_id" value="<?php echo e($lead->id); ?>">
                                        <div class="form-group">
                                            <label type="select" for="user_id">clients</label>
                                            <select name="user_id" id="user_id"
                                                class="form-control<?php echo e($errors->has('user_id') ? ' is-invalid' : ''); ?>"
                                                rows="3" required><?php echo e(old('user_id')); ?>

                                                >
                                                <option value="" selected disabled>Please Select</option>
                                                <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $clients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $clients->clientUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($user->id); ?>"
                                                            <?php echo e(old('user_id') == $user->id ? 'selected' : ''); ?>>
                                                            <?php echo e($user->representative_name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <div class="form-group">
                                                <label for="Date">Select Date </label>
                                                <input type="date"
                                                    class="form-control datepicker <?php echo e($errors->has('form-control datepicker') ? 'is-invalid' : ''); ?>"
                                                    name="follow_up_date" id="follow_up_date" rows="3"
                                                    required><?php echo e(old('follow_up_date')); ?>

                                            </div>

                                            <div class="form-group">
                                                <label for="Time">select time </label>
                                                <input
                                                    class="form-control timepicker <?php echo e($errors->has('form-control timepicker') ? 'is-invalid' : ''); ?>"
                                                    name="follow_up_time" id="follow_up_time" rows="3"
                                                    required><?php echo e(old('follow_up_time')); ?>

                                            </div>
                                            <div class="form-group">
                                                <label for="noteContent">Note Content</label>
                                                <textarea class="form-control <?php echo e($errors->has('notes') ? 'is-invalid' : ''); ?>" name="notes" id="notes"
                                                    rows="4" required><?php echo e(old('notes')); ?></textarea>
                                            </div>

                                            <div class="modal-footer">
                                                <button type="button" onclick="togglePopup()">Close</button>
                                                <button class="btn btn-danger" type="submit">
                                                    Save
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                    <?php
                        $lead_info = $lead->lead_info;
                        if (!empty($lead->source) && !empty($lead->source->name_key) && isset($lead_info[$lead->source->name_key]) && !empty($lead_info[$lead->source->name_key])) {
                            unset($lead_info[$lead->source->name_key]);
                        }

                        if (!empty($lead->source) && !empty($lead->source->email_key) && isset($lead_info[$lead->source->email_key]) && !empty($lead_info[$lead->source->email_key])) {
                            unset($lead_info[$lead->source->email_key]);
                        }

                        if (!empty($lead->source) && !empty($lead->source->phone_key) && isset($lead_info[$lead->source->phone_key]) && !empty($lead_info[$lead->source->phone_key])) {
                            unset($lead_info[$lead->source->phone_key]);
                        }

                        if (!empty($lead->source) && !empty($lead->source->additional_email_key) && isset($lead_info[$lead->source->additional_email_key]) && !empty($lead_info[$lead->source->additional_email_key])) {
                            unset($lead_info[$lead->source->additional_email_key]);
                        }

                        if (!empty($lead->source) && !empty($lead->source->secondary_phone_key) && isset($lead_info[$lead->source->secondary_phone_key]) && !empty($lead_info[$lead->source->secondary_phone_key])) {
                            unset($lead_info[$lead->source->secondary_phone_key]);
                        }
                    ?>
                    <?php $__currentLoopData = $lead_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <b><?php echo $key; ?></b>
                            <a class="float-right">
                                <?php echo $value; ?>

                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- <li class="list-group-item">
                <b><?php echo app('translator')->get('messages.sell_do_created_date'); ?></b>
                <a class="float-right">
                    <?php if(!empty($lead->sell_do_lead_created_at)): ?>
<?php echo e(\Carbon\Carbon::createFromTimestamp(strtotime($lead->sell_do_lead_created_at))->format('M d Y h:i A')); ?>

<?php endif; ?>
                </a>
            </li> -->
                    <!-- <li class="list-group-item">
                <b><?php echo app('translator')->get('messages.sell_do_status'); ?></b>
                <a class="float-right">
                    <?php echo $lead->sell_do_status ?? ''; ?>

                </a>
            </li> -->
                    <!-- <li class="list-group-item">
                <b><?php echo app('translator')->get('messages.sell_do_stage'); ?></b>
                <a class="float-right">
                    <?php echo $lead->sell_do_stage ?? ''; ?>

                </a>
            </li> -->
                    <li class="list-group-item">
                        <b><?php echo app('translator')->get('messages.customer_comments'); ?></b>
                        <a class="float-right">
                            <?php echo $lead->comments ?? ''; ?>

                        </a>
                    </li>
                    <li class="list-group-item">
                        <b><?php echo app('translator')->get('messages.cp_comments'); ?></b>
                        <a class="float-right">
                            <?php echo $lead->cp_comments ?? ''; ?>

                        </a>
                    </li>
                    <li class="list-group-item">
                        <b><?php echo app('translator')->get('messages.added_by'); ?></b>
                        <a class="float-right">
                            <?php echo e($lead->createdBy ? $lead->createdBy->name : ''); ?>

                        </a>
                    </li>
        </form>
        </ul>
        
    </div>
</div>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            datetimeElement.datetimepicker({
                format: 'DD-MM-YYYY HH:mm:ss',
                locale: 'en',
                sideBySide: true,
                icons: {
                    up: 'fas fa-chevron-up',
                    down: 'fas fa-chevron-down',
                    previous: 'fas fa-chevron-left',
                    next: 'fas fa-chevron-right'
                }
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            $('.edit-button').on('click', function() {
                // Show the edit fields and set border color to red
                $('.edit-field').show().css('border-color', 'red');
                $('.display-value').hide();
                $('.save-button').show();
                $('.edit-field').each(function() {
                    var fieldName = $(this).attr('name');
                    var displayValue = $(this).siblings('.display-value').text();
                    $(this).val(displayValue);
                });
                // Clear any previous error messages
                $('.error-message').text('');
            });

            $('.save-button').on('click', function() {
                // Create an object to store the updated values
                var updatedValues = {};
                var isValid = true;
                // Update the display values with the entered values and store in the object
                $('.display-value').each(function() {
                    var fieldName = $(this).attr('name');
                    var updatedValue = $(this).siblings('.edit-field').val();

                    // Perform validation for each field
                    switch (fieldName) {
                        case 'additional_email':
                            if (!isValidEmail(updatedValue)) {
                                isValid = false;
                                $('.error-message').text('Invalid email address.');
                            }
                            break;
                        case 'secondary_phone':
                            if (!isValidPhoneNumber(updatedValue)) {
                                isValid = false;
                                $('.error-message').text(
                                    'Invalid phone number (10 digits required).');
                            }
                            break;
                        case 'intake_year':
                            // Add validation logic if needed
                            break;
                        case 'grade_enquired':
                            // Add validation logic if needed
                            break;

                        case 'current_school':
                            // Add validation logic if needed
                            break;
                            // Add more cases for other fields as needed
                    }

                    updatedValues[fieldName] = updatedValue;
                });
                if (updatedValue.trim() === '') {
                    $(this).siblings('.edit-field').css('border-color', 'red');
                } else {
                    $(this).siblings('.edit-field').css('border-color', 'blue');
                }

                // Add the _method field for Laravel to recognize it as a PUT request
                updatedValues['_method'] = 'PUT';
                // Check if all fields are valid before making the AJAX request
                if (isValid) {
                    $.ajax({
                        method: 'POST',
                        url: '<?php echo e(route('admin.leads.update', [$lead->id])); ?>',
                        data: updatedValues,
                        success: function(response) {
                            // Handle success if needed
                            console.log(response);
                            // Hide the text fields and show the display values
                            $('.edit-field').hide();
                            $('.display-value').show();
                        },
                        error: function(error) {
                            // Log the error response
                            console.error(error.responseJSON);
                            // Show the text fields and hide the display values
                            $('.edit-field').show();
                            $('.display-value').hide();
                        }
                    });
                }
            });
        });
    </script>

<script>
    $(document).ready(function() {
        // Show the modal when the "Follow Up" button is clicked
        $('#SiteVisitButton').click(function() {
            $('#SiteVisitModal').modal('show');
        });
    });
</script>

<script>
    $(document).ready(function() {
        // Show the modal when the "Follow Up" button is clicked
        $('#FollowUpButton').click(function() {
            $('#FollowUpModal').modal('show');
        });
    });
</script>
 <script>
    $(document).ready(function() {
        // Show the modal when the "Follow Up" button is clicked
        $('#NotesButton').click(function() {
            $('#NotesModal').modal('show');
        });
    });
</script>

<?php $__env->stopSection(); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>



<script>

function checkParentStageId(selectElement) {
    var selectedOption = selectElement.options[selectElement.selectedIndex];
    var selectedName = selectedOption.text.trim().toLowerCase();

    // Hide all modals initially
    document.getElementById('rescheduleContent').style.display = 'none';
    document.getElementById('followUpContent').style.display = 'none';
    document.getElementById('siteVisitContent').style.display = 'none';

    // Check the selected option and display the corresponding modal
    if (selectedName === 'FollowUp') {
        document.getElementById('followUpContent').style.display = 'block';
    } else if (selectedName === 'Site Visit Scheduled') {
        document.getElementById('siteVisitContent').style.display = 'block';
    } else {
        document.getElementById('rescheduleContent').style.display = 'block';
    }
}

function togglePopup(formId) {
    // Add any additional logic for closing the popup if needed
    var contentId = formId + 'Content';
    document.getElementById(contentId).style.display = 'none';
}

// Initially check the value on page load
document.addEventListener('DOMContentLoaded', function () {
    checkParentStageId(document.getElementById('parent_stage_id'));
});

    $(document).ready(function() {
        $('#tag_id').change(function() {
            var selectedTagId = $('#tag_id option:selected').val();

            // Check if childStages is not null
            var childStages = <?php echo json_encode($lead->parentStage->childStages ?? null); ?>;
            console.log("Child Stages:", childStages);

            var selectedChildStages = [];

            // Check if childStages is not null and has the selected_child_stages property
            if (childStages && childStages.length > 0 && childStages[0].selected_child_stages) {
                selectedChildStages = JSON.parse(childStages[0].selected_child_stages);
            }

            console.log("Selected Child Stages:", selectedChildStages);

            $('#child_stage_id').html(
                '<option value="" selected disabled>Please Select a Tag First</option>');

            if (selectedTagId && selectedChildStages) {
                // Filter child stages based on the selected tag and lead's selected_child_stages
                <?php $__currentLoopData = $parentStages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    if ("<?php echo e($stage->tag_id); ?>" == selectedTagId && selectedChildStages.includes(
                            "<?php echo e($stage->id); ?>")) {
                        $('#child_stage_id').append(
                            '<option value="<?php echo e($stage->id); ?>" data-tag="<?php echo e($stage->tag_id); ?>"><?php echo e($stage->name); ?></option>'
                        );
                    }
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            }
        });
    });
</script>

<?php /**PATH C:\laragon\www\lms_bbc-main\resources\views/admin/leads/partials/user_details.blade.php ENDPATH**/ ?>