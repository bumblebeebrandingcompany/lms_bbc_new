<?php $__env->startSection('content'); ?>
    <h1>
        Site Visit</h1>
    <div class="card">

        <div class="card-header">
            <h3 class="card-title">Lead Site Visit Table</h3>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="campaign_name">Select Campaign Name</label>
                        <select id="campaign_name" name="campaign_name" class="form-control">
                            <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->campaign_name): ?>
                                    <!-- Check if representative_name is not null or empty -->
                                    <option value="<?php echo e($item->campaign_name); ?>"><?php echo e($item->campaign_name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="required"
                        for="user_id"><?php echo e(trans('cruds.project.fields.client')); ?></label>
                    <select class="form-control select2 <?php echo e($errors->has('client') ? 'is-invalid' : ''); ?>"
                        name="user_id" id="user_id" required>
                    <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $clients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $clients->clientUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id') == $user->id ? 'selected' : ''); ?>>
                                <?php echo e($user->representative_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                    <?php if($errors->has('client')): ?>
                        <span class="text-danger"><?php echo e($errors->first('client')); ?></span>
                    <?php endif; ?>
                    <span class="help-block"></span>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="start_date"><?php echo e(trans('cruds.project.fields.start_date')); ?></label>
                        <input class="form-control date <?php echo e($errors->has('start_date') ? 'is-invalid' : ''); ?>" type="text"
                            name="start_date" id="start_date" value="<?php echo e(old('start_date')); ?>">
                        <?php if($errors->has('start_date')): ?>
                            <span class="text-danger"><?php echo e($errors->first('start_date')); ?></span>
                        <?php endif; ?>
                        <span class="help-block"><?php echo e(trans('cruds.project.fields.start_date_helper')); ?></span>
                    </div>
                </div>
            </div>

            <table class="table">
                <thead>
                    <tr>
                        <th>Reference Number</th>
                        <th>Campaign Name</th>
                        <th>Site Visit Date</th>
                        <th>Site Visit Time</th>
                        <th>Site Visit By</th>
                        <th>Notes</th>
                        <th>Actions</th>
                        
                        <!-- Add more table headers for other lead follow-up properties -->
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $sitevisits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sitevisit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php $__currentLoopData = $lead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($leads->id === $sitevisit->lead_id): ?>
                                        <?php echo e($leads->ref_num); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php $__currentLoopData = $lead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($leads->id === $sitevisit->lead_id): ?>
                                        <?php echo e($leads->campaign->campaign_name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php $__currentLoopData = $lead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($leads->id === $sitevisit->lead_id): ?>
                                        <?php echo e($sitevisit->follow_up_date); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>

                                        <?php echo e($sitevisit->follow_up_time); ?>


                            </td>
                            
                            

                            <td>
                                <?php echo e($sitevisit->users->representative_name); ?>

                            </td>
                            <td>
                                <?php $__currentLoopData = $lead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($leads->id === $sitevisit->lead_id): ?>
                                        <?php echo e($sitevisit->notes); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>

                            <td>
                                <form action="<?php echo e(route('admin.sitevisits.reschedule', $sitevisit->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="button" class="btn btn-sm btn-warning" data-toggle="modal" data-target="#editModal<?php echo e($sitevisit->id); ?>">
                                        Reschedule
                                    </button>
                                </form>
                            </td>
                                <!-- Edit Modal -->
                                <div class="modal fade" id="editModal<?php echo e($sitevisit->id); ?>" tabindex="-1" role="dialog" aria-labelledby="editModalLabel<?php echo e($sitevisit->id); ?>" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="editModalLabel<?php echo e($sitevisit->id); ?>">Reschedule</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>

                                            <div class="modal-body">
                                                <form method="POST" action="<?php echo e(route('admin.sitevisits.reschedule', $sitevisit->id)); ?>" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <input type="hidden" name="lead_id" value="<?php echo e($sitevisit->lead_id); ?>">
                                                    <h3 class="card-title">Lead Id : <?php echo e($sitevisit->lead_id); ?></h3>

                                                    <div class="form-group">
                                                        <label class="required" for="user_id"><?php echo e(trans('cruds.project.fields.client')); ?></label>
                                                        <select class="form-control select2 <?php echo e($errors->has('client') ? 'is-invalid' : ''); ?>" name="user_id" id="user_id" required>
                                                            <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $clients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php $__currentLoopData = $clients->clientUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id') == $user->id ? 'selected' : ''); ?>>
                                                                        <?php echo e($user->representative_name); ?>

                                                                    </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <?php if($errors->has('client')): ?>
                                                            <span class="text-danger"><?php echo e($errors->first('client')); ?></span>
                                                        <?php endif; ?>
                                                        <span class="help-block"><?php echo e(trans('cruds.project.fields.client_helper')); ?></span>
                                                    </div>

                                                    <label for="Date">Select Date</label>
                                                    <input type="date" name="follow_up_date" class="form-control datepicker" value="<?php echo e($sitevisit->follow_up_date); ?>">

                                                    <label for="Time">Select Time</label>
                                                    <input id="follow_up_time" name="follow_up_time" type="text" class="form-control timepicker" value="<?php echo e($sitevisit->follow_up_time); ?>">

                                                    <div class="form-group">
                                                        <label for="followUpContent">Notes</label>
                                                        <textarea id="followUpContent" name="notes" class="form-control" rows="5"><?php echo e($sitevisit->notes); ?></textarea>
                                                    </div>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-primary">Save Changes</button>
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new__lms_bbc\resources\views/admin/sitevisit/index.blade.php ENDPATH**/ ?>