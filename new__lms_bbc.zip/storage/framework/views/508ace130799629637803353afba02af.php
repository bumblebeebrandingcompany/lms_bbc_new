<table class="table">
    <thead>
        <tr>
            <th>Reference Number</th>
            <th>Campaign Name</th>
            <th>Follow-Up Time</th>
            <th>Follow-Up Date</th>

            <th>Follow-Up By</th>
            
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $followUps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $followUp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($lead->ref_num); ?></td>
                <td><?php echo e($lead->campaign->campaign_name); ?></td>
                <td><?php echo e($followUp->follow_up_time); ?></td>
                <td><?php echo e($followUp->follow_up_date); ?></td>
                
                <td>
                    <?php echo e($followUp->users->representative_name); ?>

                </td>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


<?php /**PATH C:\laragon\www\lms_bbc-main\resources\views/admin/leads/partials/followup.blade.php ENDPATH**/ ?>