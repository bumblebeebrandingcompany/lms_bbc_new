<?php $__env->startSection('content'); ?>
<div class="row mb-2">
   <div class="col-sm-6">
        <h2>
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.lead.title_singular')); ?>

        </h2>
   </div>
</div>
<div class="card card-primary card-outline">
    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.leads.update", [$lead->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="lead_id" value="<?php echo e($lead->id); ?>" id="lead_id">
            <div class="form-group">
                <label for="name" class="required">
                    <?php echo app('translator')->get('messages.name'); ?>
                </label>
                <input type="text" name="name" id="name" value="<?php echo e(old('name') ?? $lead->name); ?>" class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" required>
            </div>
            <div class="form-group">
                <label for="email" <?php if(!auth()->user()->is_superadmin): ?> class="required" <?php endif; ?>>
                    <?php echo app('translator')->get('messages.email'); ?>
                </label>
                <input type="email" name="email" id="email" value="<?php echo e(old('email') ?? $lead->email); ?>" class="form-control" <?php if(!auth()->user()->is_superadmin): ?> required <?php endif; ?>>
            </div>
            <div class="form-group">
                <label for="additional_email_key">
                    <?php echo app('translator')->get('messages.additional_email_key'); ?>
                </label>
                <input type="email" name="additional_email" id="additional_email_key" value="<?php echo e(old('additional_email') ?? $lead->additional_email); ?>" class="form-control">
            </div>
            <input type="hidden" name="parent_stage_id" value="<?php echo e($lead->parent_stage_id); ?>">

            <div class="form-group">
                <label for="phone" <?php if(!auth()->user()->is_superadmin): ?> class="required" <?php endif; ?>>
                    <?php echo app('translator')->get('messages.phone'); ?>
                </label>
                <input type="text" name="phone" id="phone" value="<?php echo e(old('phone') ?? $lead->phone); ?>" class="form-control input_number" <?php if(!auth()->user()->is_superadmin): ?> required <?php endif; ?>>
            </div>
            <div class="form-group">
                <label for="secondary_phone_key">
                    <?php echo app('translator')->get('messages.secondary_phone_key'); ?>
                </label>
                <input type="text" name="secondary_phone" id="secondary_phone_key" value="<?php echo e(old('secondary_phone') ?? $lead->secondary_phone); ?>" class="form-control input_number">
            </div>
            <div class="form-group">
                <label class="required" for="project_id"><?php echo e(trans('cruds.lead.fields.project')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('project') ? 'is-invalid' : ''); ?>" name="project_id" id="project_id" required>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((old('project_id') ? old('project_id') : $lead->project->id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('project')): ?>
                    <span class="text-danger"><?php echo e($errors->first('project')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.lead.fields.project_helper')); ?></span>
            </div>
            <?php if(!auth()->user()->is_channel_partner): ?>
                <div class="form-group">
                    <label for="campaign_id"><?php echo e(trans('cruds.lead.fields.campaign')); ?></label>
                    <select class="form-control select2 <?php echo e($errors->has('campaign') ? 'is-invalid' : ''); ?>" name="campaign_id" id="campaign_id">
                        <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e((old('campaign_id') ? old('campaign_id') : $lead->campaign->id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('campaign')): ?>
                        <span class="text-danger"><?php echo e($errors->first('campaign')); ?></span>
                    <?php endif; ?>
                    <span class="help-block"><?php echo e(trans('cruds.lead.fields.campaign_helper')); ?></span>
                </div>
                <div class="form-group">
                    <label class="required" for="source_id"><?php echo e(trans('messages.source')); ?></label>
                    <select class="form-control select2 <?php echo e($errors->has('source_id') ? 'is-invalid' : ''); ?>" name="source_id" id="source_id" required>

                    </select>
                    <?php if($errors->has('source_id')): ?>
                        <span class="text-danger"><?php echo e($errors->first('source_id')); ?></span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <div class="form-group">
                <label for="comments"><?php echo e(trans('messages.comments')); ?></label>
                <textarea name="comments" class="form-control" id="comments" rows="2"><?php echo old('comments') ?? $lead->comments; ?></textarea>
            </div>
            <?php if(auth()->user()->is_channel_partner): ?>
                <div class="form-group">
                    <label for="cp_comments"><?php echo e(trans('messages.cp_comments')); ?></label>
                    <textarea name="cp_comments" class="form-control" id="cp_comments" rows="2"><?php echo old('comments') ?? $lead->cp_comments; ?></textarea>
                </div>
            <?php endif; ?>
            <?php if(!auth()->user()->is_channel_partner): ?>
                <h4>
                    <?php echo e(trans('cruds.lead.fields.lead_details')); ?>/<?php echo app('translator')->get('messages.additional_fields'); ?>
                    <i class="fas fa-info-circle" data-html="true" data-toggle="tooltip" title="<?php echo e(trans('messages.lead_details_help_text')); ?>"></i>
                </h4>
                <div class="lead_details">
                    <?php
                        $index_count = 0;
                    ?>
                    <?php if(empty($lead->lead_info)): ?>
                        <?php
                            $index_count = -1;
                        ?>
                        <!-- <?php if ($__env->exists('admin.leads.partials.lead_detail', ['key' => '', 'value' => '', $index = 0])) echo $__env->make('admin.leads.partials.lead_detail', ['key' => '', 'value' => '', $index = 0], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
                    <?php else: ?>
                        <?php $__currentLoopData = $lead->lead_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $index_count = $loop->index;
                            ?>
                            <?php if ($__env->exists('admin.leads.partials.lead_detail', ['key' => $key, 'value' => $value, $index = $loop->index])) echo $__env->make('admin.leads.partials.lead_detail', ['key' => $key, 'value' => $value, $index = $loop->index], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <div class="form-group">
                <?php if(!auth()->user()->is_channel_partner): ?>
                    <input type="hidden" id="index_count" value="<?php echo e($index_count ?? -1); ?>">
                    <button type="button" class="btn btn-outline-primary add_lead_detail">
                        <?php echo app('translator')->get('messages.add_lead_detail'); ?>
                    </button>
                    <button type="button" class="btn btn-outline-primary add_prefilled_lead_detail">
                        <?php echo app('translator')->get('messages.add_prefilled_lead_detail'); ?>
                    </button>
                <?php endif; ?>
                <button class="btn btn-primary float-right" type="submit">
                    <?php echo e(trans('global.update')); ?>

                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(function() {
        function getCampaigns() {
            let data = {
                project_id: $('#project_id').val()
            };

            $.ajax({
                method:"GET",
                url: "<?php echo e(route('admin.get.campaigns')); ?>",
                data: data,
                dataType: "json",
                success: function(response) {
                    $('#campaign_id').select2('destroy').empty().select2({data: response});
                    $('#campaign_id').val("<?php echo e($lead->campaign_id); ?>").change();
                    getSource();
                }
            });
        }

        function getSource() {
            let data = {
                project_id: $('#project_id').val(),
                campaign_id: $('#campaign_id').val(),
            };
            $.ajax({
                method:"GET",
                url: "<?php echo e(route('admin.get.sources')); ?>",
                data: data,
                dataType: "json",
                success: function(response) {
                    $('#source_id').select2('destroy').empty().select2({data: response});
                    $('#source_id').val("<?php echo e($lead->source_id); ?>").change();
                }
            });
        }

        $(document).on('change', '#project_id', function() {
            getCampaigns();
            getLeadDetailsRowHtml();
        });

        $(document).on('change', '#campaign_id', function() {
            getSource();
        });

        $(document).on('click', '.add_lead_detail', function() {
            let index = $("#index_count").val();
            $.ajax({
                method:"GET",
                url: "<?php echo e(route('admin.lead.detail.html')); ?>",
                data: {
                    index: index
                },
                dataType: "html",
                success: function(response) {
                    $("div.lead_details").append(response);
                    $("#index_count").val(+index + 1);
                }
            });
        });

        $(document).on('click', '.delete_lead_detail_row', function() {
            if(confirm('Do you want to remove?')) {
                $(this).closest('.row').remove();
            }
        });

        function getLeadDetailsRowHtml() {
            $.ajax({
                method:"GET",
                url: "<?php echo e(route('admin.lead.details.rows')); ?>",
                data: {
                    project_id: $('#project_id').val(),
                    lead_id: $('#lead_id').val()
                },
                dataType: "json",
                success: function(response) {
                    $("div.lead_details").html(response.html);
                    $("#index_count").val(response.count);
                }
            });
        }

        $(document).on('click', '.add_prefilled_lead_detail', function() {
            let index = $("#index_count").val();
            $.ajax({
                method:"GET",
                url: "<?php echo e(route('admin.lead.detail.html')); ?>",
                data: {
                    index: index,
                    project_id: $('#project_id').val()
                },
                dataType: "html",
                success: function(response) {
                    $("div.lead_details").append(response);
                    $("#index_count").val(+index + 1);
                    $(".select-tags").select2();
                }
            });
        });

        getCampaigns();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new__lms_bbc\resources\views/admin/leads/edit.blade.php ENDPATH**/ ?>