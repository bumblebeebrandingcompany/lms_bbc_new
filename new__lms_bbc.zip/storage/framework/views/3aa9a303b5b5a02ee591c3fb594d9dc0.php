<div class="row">
    <div class="col-md-12">
        <?php if(
            !(auth()->user()->is_channel_partner || auth()->user()->is_channel_partner_manager) &&
            !empty($lead->webhook_response)
        ): ?>
            <div class="table-responsive">
                <table class="table table-bordered text-nowrap">
                    <tbody>
                        <?php $__currentLoopData = $lead->webhook_response; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th>
                                    <?php echo e($loop->iteration); ?>

                                </th>
                                <td>
                                    <?php if(is_string($response)): ?>
                                        <?php echo e($response); ?>

                                    <?php else: ?>
                                    <?php if(
                                        !empty($response) &&
                                        array_key_exists('input', $response) &&
                                        array_key_exists('response', $response)
                                    ): ?>
                                            <div class="table-responsive">
                                                <table class="table table-bordered table-striped text-nowrap">
                                                    <thead>
                                                        <th>
                                                            Input
                                                        </th>
                                                        <th>
                                                            Output
                                                        </th>
                                                    </thead>
                                                    <tbody>
                                                        <td>
                                                            <pre>
                                                                <?php echo print_r($response['input'], true); ?>

                                                            </pre>
                                                        </td>
                                                        <td>
                                                            <pre>
                                                                <?php echo print_r($response['response'], true); ?>

                                                            </pre>
                                                        </td>
                                                    </tbody>
                                                </table>
                                            </div>
                                        <?php else: ?>
                                            <pre>
                                                <?php echo print_r($response, true); ?>

                                            </pre>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="callout callout-warning">
                <h5>No, webhook response found.</h5>
            </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH C:\laragon\www\lms_bbc-main\resources\views/admin/leads/partials/webhook_responses.blade.php ENDPATH**/ ?>