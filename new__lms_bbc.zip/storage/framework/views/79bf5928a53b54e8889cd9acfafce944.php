<?php $__env->startSection('content'); ?>
<div class="row mb-2">
   <div class="col-sm-6">
        <h2>
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.user.title_singular')); ?>

        </h2>
   </div>
</div>
<div class="card card-primary card-outline">
    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.users.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="name"><?php echo e(trans('cruds.user.fields.name')); ?></label>
                <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', '')); ?>" required>
                <?php if($errors->has('name')): ?>
                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.user.fields.name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="representative_name"><?php echo e(trans('messages.representative_name')); ?></label>
                <input class="form-control" type="text" name="representative_name" id="representative_name" value="<?php echo e(old('representative_name', '')); ?>">
            </div>
            <div class="form-group">
                <label class="required" for="email"><?php echo e(trans('cruds.user.fields.email')); ?></label>
                <input class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>" type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" required>
                <?php if($errors->has('email')): ?>
                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.user.fields.email_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="password"><?php echo e(trans('cruds.user.fields.password')); ?></label>
                <input class="form-control <?php echo e($errors->has('password') ? 'is-invalid' : ''); ?>" type="password" name="password" id="password" required>
                <?php if($errors->has('password')): ?>
                    <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.user.fields.password_helper')); ?></span>
            </div>
            <!-- <div class="form-group">
                <label class="required" for="roles"><?php echo e(trans('cruds.user.fields.roles')); ?></label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0"><?php echo e(trans('global.deselect_all')); ?></span>
                </div>
                <select class="form-control select2 <?php echo e($errors->has('roles') ? 'is-invalid' : ''); ?>" name="roles[]" id="roles" multiple required>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(in_array($id, old('roles', [])) ? 'selected' : ''); ?>><?php echo e($role); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('roles')): ?>
                    <span class="text-danger"><?php echo e($errors->first('roles')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.user.fields.roles_helper')); ?></span>
            </div> -->
            <div class="form-group">
                <label class="required"><?php echo e(trans('cruds.user.fields.user_type')); ?></label>
                <?php $__currentLoopData = App\Models\User::USER_TYPE_RADIO; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(!auth()->user()->is_channel_partner_manager): ?>
                        <div class="form-check <?php echo e($errors->has('user_type') ? 'is-invalid' : ''); ?>">
                            <input class="form-check-input user_type_input" type="radio" id="user_type_<?php echo e($key); ?>" name="user_type" value="<?php echo e($key); ?>" <?php echo e(old('user_type', '') === (string) $key ? 'checked' : ''); ?> required>
                            <label class="form-check-label" for="user_type_<?php echo e($key); ?>"><?php echo e($label); ?></label>
                        </div>
                    <?php else: ?>
                        <?php if($key == 'ChannelPartner'): ?>
                            <div class="form-check <?php echo e($errors->has('user_type') ? 'is-invalid' : ''); ?>">
                                <input class="form-check-input user_type_input" type="radio" id="user_type_<?php echo e($key); ?>" name="user_type" value="<?php echo e($key); ?>" checked required>
                                <label class="form-check-label" for="user_type_<?php echo e($key); ?>"><?php echo e($label); ?></label>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($errors->has('user_type')): ?>
                    <span class="text-danger"><?php echo e($errors->first('user_type')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.user.fields.user_type_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="address"><?php echo e(trans('cruds.user.fields.address')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('address') ? 'is-invalid' : ''); ?>" name="address" id="address"><?php echo e(old('address')); ?></textarea>
                <?php if($errors->has('address')): ?>
                    <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.user.fields.address_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="contact_number_1"><?php echo e(trans('cruds.user.fields.contact_number_1')); ?></label>
                <input class="form-control <?php echo e($errors->has('contact_number_1') ? 'is-invalid' : ''); ?>" type="text" name="contact_number_1" id="contact_number_1" value="<?php echo e(old('contact_number_1', '')); ?>">
                <?php if($errors->has('contact_number_1')): ?>
                    <span class="text-danger"><?php echo e($errors->first('contact_number_1')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.user.fields.contact_number_1_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="contact_number_2"><?php echo e(trans('cruds.user.fields.contact_number_2')); ?></label>
                <input class="form-control <?php echo e($errors->has('contact_number_2') ? 'is-invalid' : ''); ?>" type="text" name="contact_number_2" id="contact_number_2" value="<?php echo e(old('contact_number_2', '')); ?>">
                <?php if($errors->has('contact_number_2')): ?>
                    <span class="text-danger"><?php echo e($errors->first('contact_number_2')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.user.fields.contact_number_2_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="website"><?php echo e(trans('cruds.user.fields.website')); ?></label>
                <input class="form-control <?php echo e($errors->has('website') ? 'is-invalid' : ''); ?>" type="text" name="website" id="website" value="<?php echo e(old('website', '')); ?>">
                <?php if($errors->has('website')): ?>
                    <span class="text-danger"><?php echo e($errors->first('website')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.user.fields.website_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="client_id"><?php echo e(trans('cruds.user.fields.client')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('client') ? 'is-invalid' : ''); ?>" name="client_id" id="client_id">
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('client_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('client')): ?>
                    <span class="text-danger"><?php echo e($errors->first('client')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.user.fields.client_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="agency_id"><?php echo e(trans('cruds.user.fields.agency')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('agency') ? 'is-invalid' : ''); ?>" name="agency_id" id="agency_id">
                    <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('agency_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('agency')): ?>
                    <span class="text-danger"><?php echo e($errors->first('agency')); ?></span>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.user.fields.agency_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="assign_client"><?php echo e(trans('messages.assign_client')); ?></label>
                <select class="form-control select2" name="client_assigned" id="assign_client" required>
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('client_assigned') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label class="required" for="projects"><?php echo e(trans('messages.projects')); ?></label>
                <select class="form-control select2" name="project_assigned[]" id="projects" multiple>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>">
                            <?php echo e($entry); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <span class="help-block"><?php echo e(trans('messages.project_help_text')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    <?php if ($__env->exists('admin.users.partials.user_crud_js')) echo $__env->make('admin.users.partials.user_crud_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new__lms_bbc\resources\views/admin/users/create.blade.php ENDPATH**/ ?>