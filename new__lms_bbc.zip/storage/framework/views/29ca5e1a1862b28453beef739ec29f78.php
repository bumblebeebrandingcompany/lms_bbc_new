<?php $__env->startSection('content'); ?>
    <h1>
        Lead Follow Up List</h1>
    <div class="card">

        <div class="card-header">
            <h3 class="card-title">Lead Follow-Up Table</h3>
        </div>
        <div class="card-body">
            <div class="row">
            <?php if(!(auth()->user()->is_channel_partner || auth()->user()->is_channel_partner_manager)): ?>
                        <div class="col-md-3 campaigns_div">
                            <label for="campaign_id">
campaign                            </label>
                            <select class="search form-control" id="campaign_id">
                                <option value><?php echo e(trans('global.all')); ?></option>
                                <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php if(isset($filters['campaign_id']) && $filters['campaign_id'] == $item->id): ?> selected <?php endif; ?>><?php echo e($item->campaign_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    <?php endif; ?>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="user_id">Select Staff Member</label>
                        <select name="user_id" id="user_id" class="form-control<?php echo e($errors->has('user_id') ? ' is-invalid' : ''); ?>"
                    rows="3" required><?php echo e(old('user_id')); ?>

>
<option value><?php echo e(trans('global.all')); ?></option>

                        <!-- <option value="" selected disabled>Please Select</option> -->
                        <?php $__currentLoopData = $agencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $agency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $agency->agencyUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id') == $user->id ? 'selected' : ''); ?>>
                                    <?php echo e($user->representative_name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    </div>
                </div>
            <div class="col-md-3">
                            <label for="added_on"><?php echo e(trans('messages.added_on')); ?></label>
                            <input class="form-control date_range" type="text" name="date" id="added_on" readonly>
                        </div>
            <table class="table table-bordered table-striped table-hover ajaxTable datatable datatable-Followup">
                <thead>
                    <tr>
                        <th><?php echo e(trans('messages.ref_num')); ?></th>
                        <th>campaign</th>
                        <th><?php echo e(trans('messages.follow_up_date')); ?></th>
                        <th><?php echo e(trans('messages.follow_up_time')); ?></th>
                        <th><?php echo e(trans('messages.follow_up_by')); ?></th>
                        <th><?php echo e(trans('messages.notes')); ?></th>
                        <th><?php echo e(trans('messages.created_at')); ?></th>

                        
                        <!-- Add more table headers for other lead follow-up properties -->
                    </tr>
                </thead>
                <tbody id="followUpTableBody">
                    <?php $__currentLoopData = $followUps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $followUp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php $__currentLoopData = $lead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($leads->id === $followUp->lead_id): ?>
                                        <?php echo e($leads->ref_num); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php $__currentLoopData = $lead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($leads->id === $followUp->lead_id): ?>
                                        <?php echo e($leads->campaign->campaign_name); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php $__currentLoopData = $lead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($leads->id === $followUp->lead_id): ?>
                                        <?php echo e($followUp->follow_up_date); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php $__currentLoopData = $lead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($leads->id === $followUp->lead_id): ?>
                                        <?php echo e($followUp->follow_up_time); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>

                            <td>
                                <?php echo e($followUp->users->representative_name); ?>

                            </td>
                            <td>
                                        <?php echo e($followUp->notes); ?>                          
                            </td>
                            <td>
                                <?php $__currentLoopData = $lead; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($leads->id === $followUp->lead_id): ?>
                                        <?php echo e($followUp->created_at); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('scripts'); ?>
        <?php echo \Illuminate\View\Factory::parentPlaceholder('scripts'); ?>

        <script>

    $(function () {
       <?php if ($__env->exists('admin.leads.partials.follow_up_js')) echo $__env->make('admin.leads.partials.follow_up_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new__lms_bbc\resources\views/admin/leads/followup/index.blade.php ENDPATH**/ ?>