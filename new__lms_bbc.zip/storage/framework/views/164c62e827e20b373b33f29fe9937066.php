<label for="source_id">
    <?php echo app('translator')->get('messages.source'); ?>
</label>
<select class="form-control" id="source_id">
    <option value><?php echo e(trans('global.all')); ?></option>
    <?php $__currentLoopData = $sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select><?php /**PATH C:\laragon\www\lms_bbc-main\resources\views/admin/projects/partials/sources_dropdown.blade.php ENDPATH**/ ?>