<aside class="main-sidebar sidebar-dark-primary elevation-4" style="min-height: 917px; overflow-y: auto;">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
        <span class="brand-text font-weight-light">
            <?php echo e(config('app.name', 'LMS')); ?>

        </span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar user (optional) -->

        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <?php if(auth()->user()->is_superadmin): ?>
                    <li>
                        <select class="searchable-field form-control">

                        </select>
                    </li>
                    <li class="mt-2 mb-2">
                        <select class="form-control mt-2" multiple name="__global_clients_filter" id="__global_clients_filter">
                            <?php $__currentLoopData = $__global_clients_drpdwn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($id); ?>"
                                    <?php if(!empty($__global_clients_filter) && in_array($id, $__global_clients_filter)): ?>
                                        selected
                                    <?php endif; ?>>
                                    <?php echo e($name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </li>
                <?php endif; ?>
                <?php if(!(auth()->user()->is_channel_partner || auth()->user()->is_channel_partner_manager)): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs("admin.home") ? "active" : ""); ?>" href="<?php echo e(route("admin.home")); ?>">
                            <i class="fas fa-fw fa-tachometer-alt nav-icon">
                            </i>
                            <p>
                                <?php echo e(trans('global.dashboard')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(auth()->user()->is_superadmin): ?>
                    <!-- <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs("admin.webhook.incoming.list") ? "active" : ""); ?>" href="<?php echo e(route("admin.webhook.incoming.list")); ?>">
                            <i class="fas fa-satellite-dish nav-icon fa-fw"></i>
                            <p>
                                <?php echo e(trans('messages.webhook')); ?>

                            </p>
                        </a>
                    </li> -->
                    <li class="nav-item has-treeview <?php echo e(request()->is('admin/documents*') ? 'menu-open' : ''); ?> <?php echo e(request()->routeIs('admin.get.documents.log') ? 'menu-open' : ''); ?>">
                        <a class="nav-link nav-dropdown-toggle <?php echo e(request()->is('admin/documents*') ? 'active' : ''); ?> <?php echo e(request()->routeIs('admin.get.documents.log') ? 'active' : ''); ?>" href="#">
                            <i class=" fa-fw nav-icon fas fa-folder-open"></i>
                            <p>
                                <?php echo e(trans('messages.documents_management')); ?>

                                <i class="right fa fa-fw fa-angle-left nav-icon ml-3"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs("admin.documents.*") ? "active" : ""); ?>" href="<?php echo e(route("admin.documents.index")); ?>">
                                    <i class="fas fa-question-circle nav-icon fa-fw"></i>
                                    <p>
                                        <?php echo e(trans('messages.documents')); ?>

                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs("admin.get.documents.log") ? "active" : ""); ?>" href="<?php echo e(route("admin.get.documents.log")); ?>">
                                    <i class="fas fa-history nav-icon fa-fw"></i>
                                    <p>
                                        <?php echo e(trans('messages.document_logs')); ?>

                                    </p>
                                </a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if(auth()->user()->is_superadmin || auth()->user()->is_channel_partner_manager): ?>
                    <li class="nav-item has-treeview <?php echo e(request()->is("admin/permissions*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/roles*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/users*") ? "menu-open" : ""); ?> <?php echo e(request()->is("admin/audit-logs*") ? "menu-open" : ""); ?>">
                        <a class="nav-link nav-dropdown-toggle <?php echo e(request()->is("admin/permissions*") ? "active" : ""); ?> <?php echo e(request()->is("admin/roles*") ? "active" : ""); ?> <?php echo e(request()->is("admin/users*") ? "active" : ""); ?> <?php echo e(request()->is("admin/audit-logs*") ? "active" : ""); ?>" href="#">
                            <i class="fa-fw nav-icon fas fa-users">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.userManagement.title')); ?>

                                <i class="right fa fa-fw fa-angle-left nav-icon"></i>
                            </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <li class="nav-item">
                                <a href="<?php echo e(route("admin.users.index")); ?>" class="nav-link <?php echo e(request()->is("admin/users") || request()->is("admin/users/*") ? "active" : ""); ?>">
                                    <i class="fa-fw nav-icon fas fa-user">

                                    </i>
                                    <p>
                                        <?php echo e(trans('cruds.user.title')); ?>

                                    </p>
                                </a>
                            </li>
                            <?php if(auth()->user()->is_superadmin): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.audit-logs.index")); ?>" class="nav-link <?php echo e(request()->is("admin/audit-logs") || request()->is("admin/audit-logs/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-file-alt">
                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.auditLog.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <?php if(auth()->user()->is_superadmin): ?>
                        <li class="nav-item has-treeview <?php echo e(request()->is("admin/clients*") ? "menu-open" : ""); ?>">
                            <a class="nav-link nav-dropdown-toggle <?php echo e(request()->is("admin/clients*") ? "active" : ""); ?>" href="#">
                                <i class="fa-fw nav-icon fas fa-briefcase">
                                </i>
                                <p>
                                    <?php echo e(trans('cruds.clientManagement.title')); ?>

                                    <i class="right fa fa-fw fa-angle-left nav-icon"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.clients.index")); ?>" class="nav-link <?php echo e(request()->is("admin/clients") || request()->is("admin/clients/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-briefcase">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.client.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item has-treeview <?php echo e(request()->is("admin/agencies*") ? "menu-open" : ""); ?>">
                            <a class="nav-link nav-dropdown-toggle <?php echo e(request()->is("admin/agencies*") ? "active" : ""); ?>" href="#">
                                <i class="fa-fw nav-icon fas fa-tv">

                                </i>
                                <p>
                                    <?php echo e(trans('cruds.agencyManagement.title')); ?>

                                    <i class="right fa fa-fw fa-angle-left nav-icon"></i>
                                </p>
                            </a>
                            <ul class="nav nav-treeview">
                                <li class="nav-item">
                                    <a href="<?php echo e(route("admin.agencies.index")); ?>" class="nav-link <?php echo e(request()->is("admin/agencies") || request()->is("admin/agencies/*") ? "active" : ""); ?>">
                                        <i class="fa-fw nav-icon fas fa-tv">

                                        </i>
                                        <p>
                                            <?php echo e(trans('cruds.agency.title')); ?>

                                        </p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if(auth()->user()->is_superadmin): ?>
                                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.projects.index")); ?>" class="nav-link <?php echo e(request()->is("admin/projects") || request()->is("admin/projects/*") ? "active" : ""); ?>">
                            <i class="fa-fw nav-icon fas fa-project-diagram">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.project.title')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(auth()->user()->is_superadmin): ?>
                                <li class="nav-item">
                    <a href="<?php echo e(route("admin.followups.index")); ?>" class="nav-link <?php echo e(request()->is("admin/followups") || request()->is("admin/followups/*") ? "active" : ""); ?>">
                        <i class="fas fa-fw fa-calendar nav-icon">

                        </i>
                        <p>
                            Lead FollowUp
                        </p>
                    </a>
                </li>
            <?php endif; ?>
            <?php if(auth()->user()->is_superadmin): ?>
            <li class="nav-item">
                <a href="<?php echo e(route("admin.sitevisit.index")); ?>" class="nav-link <?php echo e(request()->is("admin/sitevisit") || request()->is("admin/sitevisit/*") ? "active" : ""); ?>">
                    <i class="fas fa-fw fa-calendar nav-icon">

                    </i>
                    <p>
                        Site Visit
                    </p>
                </a>
            </li>
        <?php endif; ?>
                 
                <?php if(auth()->user()->is_superadmin): ?>
                                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.campaigns.index")); ?>" class="nav-link <?php echo e(request()->is("admin/campaigns") || request()->is("admin/campaigns/*") ? "active" : ""); ?>">
                            <i class="fa-fw nav-icon fas fa-bullhorn">

                            </i>
                            <p>
                                <?php echo e(trans('cruds.campaign.title')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                
                <?php if(auth()->user()->is_superadmin): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.sources.index")); ?>" class="nav-link <?php echo e(request()->is("admin/sources") || request()->is("admin/sources/*") ? "active" : ""); ?>">
                            <i class="fa-fw nav-icon fas fa-external-link-alt"></i>
                            <p>
                                <?php echo e(trans('cruds.source.title')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if(auth()->user()->is_superadmin): ?>
                <li class="nav-item">
                    <a href="<?php echo e(route("admin.parent-stages.index")); ?>" class="nav-link <?php echo e(request()->is("admin/parent-stages") || request()->is("admin/parent-stages/*") ? "active" : ""); ?>">
                        <i class="fa-fw nav-icon fas fa-external-link-alt"></i>
                        <p>
                            <?php echo e(trans('cruds.stages.title')); ?>

                        </p>
                    </a>
                </li>
            <?php endif; ?>
                <li class="nav-item">
                    <a href="<?php echo e(route('admin.leads.index', ['view' => 'list'])); ?>" id="lead_menu_link" class="nav-link <?php echo e(request()->is("admin/leads") || request()->is("admin/leads/*") ? "active" : ""); ?>">
                        <i class="fa-fw nav-icon fas fa-handshake">
                        </i>
                        <p>
                            <?php echo e(trans('cruds.lead.title')); ?>

                        </p>
                    </a>
                </li>
                <?php if(auth()->user()->is_superadmin): ?>
                                    <li class="nav-item">
                        <a href="<?php echo e(route("admin.systemCalendar")); ?>" class="nav-link <?php echo e(request()->is("admin/system-calendar") || request()->is("admin/system-calendar/*") ? "active" : ""); ?>">
                            <i class="fas fa-fw fa-calendar nav-icon">

                            </i>
                            <p>
                                <?php echo e(trans('global.systemCalendar')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->is('profile/password') || request()->is('profile/password/*') ? 'active' : ''); ?>" href="<?php echo e(route('profile.password.edit')); ?>">
                            <i class="fas fa-user nav-icon"></i>
                            <p>
                                <?php echo e(trans('messages.profile')); ?>

                            </p>
                        </a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a href="#" class="nav-link" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                        <p>
                            <i class="fas fa-fw fa-sign-out-alt nav-icon">

                            </i>
                            <p><?php echo e(trans('global.logout')); ?></p>
                        </p>
                    </a>
                </li>

            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
<?php /**PATH C:\xampp\htdocs\new__lms_bbc\resources\views/partials/menu.blade.php ENDPATH**/ ?>