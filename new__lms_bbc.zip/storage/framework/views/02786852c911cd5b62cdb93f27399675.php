<div class="container-fluid h-100">
    <?php $__currentLoopData = $lead_stages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage => $lead_stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            if ($stage == 'no_stage') {
                $leads = $stage_wise_leads[''] ?? [];
            } else {
                $leads = $stage_wise_leads[$stage] ?? [];
            }
        ?>
        <?php if(!empty($leads)): ?>
            <div class="card card-row <?php echo e($lead_stage['class'] ?? 'card-secondary'); ?>">
                <div class="card-header">
                    <h3 class="card-title">
                        <?php echo e($lead_stage['title'] ?? ucfirst(str_replace('_', ' ', $stage))); ?>

                    </h3>
                </div>
                <div class="card-body">
                    <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div
                        class="card card-outline <?php echo e($lead_stage['class'] ??
                            'card
                                                -secondary'); ?>">
                        <div class="card-header">
                            <h5 class="card-title">
                                <?php echo e(ucfirst($lead->name ?? '')); ?>

                                <small>
                                    <?php echo $lead->ref_num ? '(<code>' . $lead->ref_num . '</code>)' : ''; ?>

                                </small>
                            </h5>
                            <div class="card-tools">
                                <input class="form-check-input lead_ids" type="checkbox" id="<?php echo e($lead->id); ?>"
                                    value="<?php echo e($lead->id); ?>">
                                <a href="<?php echo e(route('admin.leads.show', [$lead->id])); ?>" class="btn btn-tool btn-link">
                                    <i class="far fa-eye text-primary"></i>
                                </a>
                                <?php if(auth()->user()->is_superadmin): ?>
                                    <a href="<?php echo e(route('admin.leads.edit', [$lead->id])); ?>" class="btn btn-tool">
                                        <i class="far fa-edit text-info"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.leads.destroy', [$lead->id])); ?>" method="POST"
                                        onsubmit="return confirm('<?php echo e(trans('global.areYouSure')); ?>');"
                                        style="display: inline-block;">
                                        <input type="hidden" name="_method" value="DELETE">
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        <button type="submit" class="btn btn-tool">
                                            <i class="far fa-trash-alt text-danger"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <strong><?php echo app('translator')->get('messages.email'); ?></strong>:
                                    <?php if(auth()->user()->is_agency && !empty($lead->email)): ?>
                                        <?php echo e(maskEmail($lead->email)); ?>

                                    <?php else: ?>
                                        <?php echo e($lead->email ?? ''); ?>

                                    <?php endif; ?>
                                </div>
                                <div class="col-md-12">
                                    <strong> <?php echo e(trans('messages.child_name')); ?>

                                    </strong>:
                                    <?php echo e($lead->child_name ?? ''); ?>

                                </div>
                                <div class="col-md-12">
                                    <strong> <?php echo e(trans('messages.grade_enquired')); ?>

                                    </strong>:
                                    <?php echo e($lead->grade_enquired ?? ''); ?>

                                </div>
                                <div id="additional-details-<?php echo e($lead->id); ?>" class="additional-details-container">

                                    <div class="col-md-12">
                                        <strong><?php echo app('translator')->get('messages.phone'); ?></strong>:
                                        <?php if(auth()->user()->is_agency && !empty($lead->phone)): ?>
                                            <?php echo e(maskNumber($lead->phone)); ?>

                                        <?php else: ?>
                                            <?php echo e($lead->phone ?? ''); ?>

                                        <?php endif; ?>
                                    </div>
                                    <!-- <div class="col-md-12">
                                        <strong><?php echo app('translator')->get('messages.status'); ?></strong>:
                                        <?php echo e($lead->sell_do_status); ?>

                                    </div> -->
                                    <div class="col-md-12">
                                        <strong><?php echo e(trans('cruds.lead.fields.project')); ?></strong>:
                                        <?php echo e($lead->project->name ?? ''); ?>

                                    </div>
                                    <div class="col-md-12">
                                        <strong> <?php echo e(trans('messages.intake_year')); ?>

                                        </strong>:
                                        <span class="display-value"><?php echo e($lead->intake_year ?? ''); ?></span>
                                    </div>
                                    <div class="col-md-12">
                                        <strong><?php echo e(trans('cruds.lead.fields.campaign')); ?></strong>:
                                        <?php echo e($lead->campaign->campaign_name ?? ''); ?>

                                    </div>
                                    <div class="col-md-12">
                                        <strong><?php echo e(trans('messages.source')); ?></strong>:
                                        <?php echo e($lead->source->name ?? ''); ?>

                                    </div>
                                    <div class="col-md-12">
                                        <strong><?php echo app('translator')->get('messages.created_at'); ?></strong>:
                                        <?php if(!empty($lead->created_at)): ?>
                                            <?php echo e(\Carbon\Carbon::createFromTimestamp(strtotime($lead->created_at))->format('M d Y h:i A')); ?>

                                        <?php endif; ?>
                                    </div>
                                </div>
                                <!-- Add more details as needed -->
                            </div>
                            <div class="col-md-12 text-center"> <!-- Center the button within its parent -->
                                <button class="btn btn-info btn-xs toggle-details-btn"
                                    data-target="<?php echo e($lead->id); ?>">
                                    <i class="fas fa-plus"></i> <!-- Initial plus icon -->
                                    <i class="fas fa-minus" style="display: none;"></i>
                                    <!-- Minus icon initially hidden -->
                                </button>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">
                                <?php echo app('translator')->get('messages.no_leads_found'); ?>
                            </h5>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>





<?php /**PATH C:\xampp\htdocs\new__lms_bbc\resources\views/admin/leads/partials/kanban/kanban.blade.php ENDPATH**/ ?>