<?php $__env->startSection('content'); ?>
    <div class="row mb-2">
        <div class="col-sm-12">
            <h2>
                <?php echo app('translator')->get('messages.configure_webhook_details'); ?>
                <small>
                    <strong>Source:</strong>
                    <span class="text-primary"><?php echo e($source->name); ?></span>
                    <strong>Project:</strong>
                    <span class="text-primary"><?php echo e(optional($source->project)->name); ?></span>
                </small>
            </h2>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card card-primary card-outline">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-6">
                            <h3 class="card-title">
                                <?php echo e(trans('messages.receive_webhook')); ?>

                            </h3>
                        </div>
                        <div class="col-md-6">
                            <a class="btn btn-default float-right" href="<?php echo e(route('admin.sources.index')); ?>">
                                <i class="fas fa-chevron-left"></i>
                                <?php echo e(trans('global.back_to_list')); ?>

                            </a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group webhook_div">
                                    <label for="webhook_url">
                                        <?php echo e(trans('messages.webhook_url')); ?>

                                    </label>
                                    <div class="input-group">
                                        <input type="text" id="webhook_url"
                                            value="<?php echo e(route('webhook.processor', ['secret' => $source->webhook_secret])); ?>"
                                            class="form-control cursor-pointer copy_link" readonly>
                                        <div class="input-group-append cursor-pointer copy_link">
                                            <span class="input-group-text">
                                                <i class="fas fa-copy"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-5">
                            <div class="col-md-12 d-flex justify-content-between mb-2">
                                <h3>
                                    <?php echo e(trans('messages.most_recent_lead')); ?>

                                </h3>
                                <button type="button" class="btn btn-outline-primary btn-xs refresh_latest_lead">
                                    <i class="fas fa-sync"></i>
                                    <?php echo e(trans('messages.refresh')); ?>

                                </button>
                            </div>
                            <div class="col-md-12">
                                <div class="table-responsive">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th><?php echo e(trans('messages.key')); ?></th>
                                                <th><?php echo e(trans('messages.value')); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if(!empty($lead) && !empty($lead->lead_info)): ?>
                                                <?php
                                                    $serial_num = 0;
                                                ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e(trans('messages.name')); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo $lead->name ?? ''; ?>

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <?php echo e(trans('messages.email')); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo $lead->email ?? ''; ?>

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <?php echo app('translator')->get('messages.additional_email_key'); ?>
                                                    </td>
                                                    <td>
                                                        <?php echo e($lead->additional_email ?? ''); ?>

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <?php echo e(trans('messages.phone')); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo $lead->phone ?? ''; ?>

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <?php echo app('translator')->get('messages.secondary_phone_key'); ?>
                                                    </td>
                                                    <td>
                                                        <?php echo e($lead->secondary_phone ?? ''); ?>

                                                    </td>
                                                </tr>
                                                        <tr>
                                                        <td>
                                                           essential_fields
                                                        </td>
                                                    <td>
                                                        <?php echo e($lead->essential_fields ?? ''); ?>

                                                    </td>
                                                </tr>
                                                <?php
                                                    $lead_info = $lead->lead_info;
                                                    $existing_keys = array_keys($lead->lead_info);
                                                    if (!empty($lead->source) && !empty($lead->source->name_key) && isset($lead_info[$lead->source->name_key]) && !empty($lead_info[$lead->source->name_key])) {
                                                        unset($lead_info[$lead->source->name_key]);
                                                    }
                                                    if (!empty($lead->source) && !empty($lead->source->email_key) && isset($lead_info[$lead->source->email_key]) && !empty($lead_info[$lead->source->email_key])) {
                                                        unset($lead_info[$lead->source->email_key]);
                                                    }

                                                    if (!empty($lead->source) && !empty($lead->source->phone_key) && isset($lead_info[$lead->source->phone_key]) && !empty($lead_info[$lead->source->phone_key])) {
                                                        unset($lead_info[$lead->source->phone_key]);
                                                    }

                                                    if (!empty($lead->source) && !empty($lead->source->additional_email_key) && isset($lead_info[$lead->source->additional_email_key]) && !empty($lead_info[$lead->source->additional_email_key])) {
                                                        unset($lead_info[$lead->source->additional_email_key]);
                                                    }

                                                    if (!empty($lead->source) && !empty($lead->source->secondary_phone_key) && isset($lead_info[$lead->source->secondary_phone_key]) && !empty($lead_info[$lead->source->secondary_phone_key])) {
                                                        unset($lead_info[$lead->source->secondary_phone_key]);
                                                    }
                                                ?>
                                                <?php $__currentLoopData = $lead_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $serial_num = $loop->iteration;
                                                    ?>
                                                    <tr>
                                                        <td>
                                                            <?php echo $key; ?>

                                                        </td>
                                                        <td>
                                                            <?php echo $value; ?>

                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e(trans('messages.created_at')); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e(\Carbon\Carbon::parse($lead->created_at)->diffForHumans()); ?>

                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <?php echo e(trans('messages.updated_at')); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e(\Carbon\Carbon::parse($lead->updated_at)->diffForHumans()); ?>

                                                    </td>
                                                </tr>
                                            <?php else: ?>
                                                <tr>
                                                    <td colspan="2" class="text-center">
                                                        <span class="text-center">
                                                            <?php echo e(trans('messages.no_data_found')); ?>

                                                        </span>
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        
                        <div class="row">
                            <div class="col-md-12">
                                <?php if($source->project->essential_fields): ?>
                                    <?php $__currentLoopData = $source->project->essential_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $essentialField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($essentialField['enabled']) && $essentialField['enabled'] === '1'): ?>
                                            <div class="row mb-3">
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label
                                                            for="essential_fields"><?php echo e($essentialField['name_data']); ?></label>
                                                        <input type="hidden"
                                                            name="sales_fields[<?php echo e($key); ?>][name_data]"
                                                            value="<?php echo e($essentialField['name_data']); ?>">
                                                        <br>
                                                        <span class="help-block"><?php echo e($essentialField['name_value']); ?></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-5">
                                                    <div class="form-group">
                                                        <br>
                                                        <select class="form-control select2" required>
                                                            <option value=""><?php echo app('translator')->get('messages.please_select'); ?></option>
                                                            <?php
                                                                $existing_keys = optional($source->project)->webhook_fields ?? [];
                                                            ?>
                                                            <?php $__currentLoopData = $existing_keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $existingKey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($existingKey); ?>">
                                                                    <?php echo e($existingKey); ?>

                                                                    <?php if(!empty($existing_keys) && in_array($existingKey, $existing_keys)): ?>
                                                                        (<?php echo app('translator')->get('messages.exist_in_recent_lead'); ?>)
                                                                    <?php endif; ?>
                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <input type="text" class="lead-input"
                                                            name="essential_fields[<?php echo e($key); ?>][value]" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <?php endif; ?>
                            </div>
                        </div>

                        
                        <div class="row">
                            <div class="col-md-12">
                                <?php if($source->project->custom_fields): ?>
                                    <?php $__currentLoopData = $source->project->custom_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($customField['enabled']) && $customField['enabled'] === '1'): ?>
                                            <div class="row mb-3">
                                                <div class="col-md-4">
                                                    <div class="form-group">

                                                        <label for="custom_fields"><?php echo e($customField['name_data']); ?></label>
                                                        <input type="hidden"
                                                            name="sales_fields[<?php echo e($key); ?>][name_data]"
                                                            value="<?php echo e($customField['name_data']); ?>">
                                                        <br>
                                                        <span class="help-block"><?php echo e($customField['name_value']); ?></span>

                                                    </div>
                                                </div>
                                                <div class="col-md-5">
                                                    <div class="form-group">
                                                        <br>
                                                        <select class="form-control select2" required>
                                                            <option value=""><?php echo app('translator')->get('messages.please_select'); ?></option>
                                                            <?php
                                                            $existing_keys = optional($source->project)->webhook_fields ?? [];
                                                            ?>
                                                            <?php $__currentLoopData = $existing_keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $existingKey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($existingKey); ?>">
                                                                    <?php echo e($existingKey); ?>

                                                                    <?php if(!empty($existing_keys) && in_array($existingKey, $existing_keys)): ?>
                                                                        (<?php echo app('translator')->get('messages.exist_in_recent_lead'); ?>)
                                                                    <?php endif; ?>
                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <input type="text" class="lead-input"
                                                            name="sales_fields[<?php echo e($key); ?>][value]" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <?php endif; ?>
                            </div>
                        </div>


                        
                        <div class="row">
                            <div class="col-md-12">
                                <?php if($source->project->sales_fields): ?>
                                    <?php $__currentLoopData = $source->project->sales_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $salesField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($salesField['enabled']) && $salesField['enabled'] === '1'): ?>
                                            <div class="row mb-3">
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="sales_fields"><?php echo e($salesField['name_data']); ?></label>
                                                        <input type="hidden"
                                                            name="sales_fields[<?php echo e($key); ?>][name_data]"
                                                            value="<?php echo e($salesField['name_data']); ?>">
                                                        <br>
                                                        <span class="help-block"><?php echo e($salesField['name_value']); ?></span>
                                                    </div>
                                                </div>
                                                <select class="form-control select2" required>
                                                    <option value=""><?php echo app('translator')->get('messages.please_select'); ?></option>
                                                    <?php
                                                     $existing_keys = optional($source->project)->webhook_fields ?? [];
                                                    ?>
                                                    <?php $__currentLoopData = $existing_keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $existingKey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($existingKey); ?>">
                                                            <?php echo e($existingKey); ?>

                                                            <?php if(!empty($existing_keys) && in_array($existingKey, $existing_keys)): ?>
                                                                (<?php echo app('translator')->get('messages.exist_in_recent_lead'); ?>)
                                                            <?php endif; ?>
                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <input type="text" class="lead-input"
                                                            name="sales_fields[<?php echo e($key); ?>][value]" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div class="form-group">
                                        <input type="text" name="sales_fields[description]" value=""
                                            class="form-control">
                                        <div class="col-md-1 mt-auto mb-auto">
                                            <div class="form-group">
                                                <button type="button"
                                                    class="btn btn-danger btn-sm float-right delete_request_body_row">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        
                        <div class="row">
                            <div class="col-md-12">
                                <?php if($source->project->system_fields): ?>
                                    <?php $__currentLoopData = $source->project->system_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $systemField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($systemField['enabled']) && $systemField['enabled'] === '1'): ?>
                                            <div class="row mb-3">
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label for="system_fields"><?php echo e($systemField['name_data']); ?></label>
                                                        <input type="hidden"
                                                            name="system_fields[<?php echo e($key); ?>][name_data]"
                                                            value="<?php echo e($systemField['name_data']); ?>">
                                                        <br>
                                                        <span class="help-block"><?php echo e($systemField['name_value']); ?></span>
                                                    </div>
                                                </div>
                                                <div class="col-md-5">
                                                    <div class="form-group">
                                                        <select class="form-control select2" required>
                                                            <option value=""><?php echo app('translator')->get('messages.please_select'); ?></option>
                                                            <?php
                                                                $tags = optional($source->project)->webhook_fields ?? [];
                                                            ?>
                                                            <?php $__currentLoopData = $existing_keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $existingKey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($existingKey); ?>">
                                                                    <?php echo e($existingKey); ?>

                                                                    <?php if(!empty($existing_keys) && in_array($existingKey, $existing_keys)): ?>
                                                                        (<?php echo app('translator')->get('messages.exist_in_recent_lead'); ?>)
                                                                    <?php endif; ?>
                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-3">
                                                    <div class="form-group">
                                                        <input type="text" class="lead-input"
                                                            name="sales_fields[<?php echo e($key); ?>][value]" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div class="form-group">
                                        <input type="text" name="system_fields[description]" value=""
                                            class="form-control">
                                        <div class="col-md-1 mt-auto mb-auto">
                                            <div class="form-group">
                                                <button type="button"
                                                    class="btn btn-danger btn-sm float-right delete_request_body_row">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>


                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        var leadData = <?php echo json_encode($lead); ?>;


        $('.select2').change(function() {
            const selectedKey = $(this).val();
            const inputField = $(this).closest('.row').find('.lead-input');

            // Retrieve the corresponding value from the leadData object
            const selectedValue = leadData[selectedKey];

            // Set the input field's value to the selected value (or handle "not found" case)
            if (selectedValue !== undefined) {
                inputField.val(selectedValue);
            } else {
                inputField.val('Value not found');
            }
        });
    </script>
    <script>
        $(function() {
            $(document).on('click', '.copy_link', function() {
                copyToClipboard($("#webhook_url").val());
            });

            function copyToClipboard(text) {
                const textarea = document.createElement('textarea');
                textarea.value = text;
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);

                const span = document.createElement('span');
                span.innerText = 'Link copied to clipboard!';
                $(".webhook_div").append(span);
                setTimeout(() => {
                    span.remove();
                }, 300);
            }

            $(document).on('click', '.refresh_latest_lead', function() {
                location.reload();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lms_bbc-main\resources\views/admin/sources/webhook.blade.php ENDPATH**/ ?>