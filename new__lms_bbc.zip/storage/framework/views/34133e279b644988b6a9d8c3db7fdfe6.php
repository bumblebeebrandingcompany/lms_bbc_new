
<div class="row">
    <div class="col-md-5">
        <?php if($project->essential_fields): ?>
        <?php $__currentLoopData = $project->essential_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $essentialField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if(isset($essentialField['enabled']) && $essentialField['enabled'] === "1"): ?>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="required">
                                <?php echo app('translator')->get('messages.key'); ?>
                            </label>
                            <input type="text" name="api[<?php echo e($webhook_key); ?>][request_body][<?php echo e($rb_key); ?>][essential_fields][key][]" value="<?php echo e($essentialField['name_key']); ?>" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="required">
                                <?php echo app('translator')->get('messages.value'); ?>
                            </label>
                            <input type="text" name="api[<?php echo e($webhook_key); ?>][request_body][<?php echo e($rb_key); ?>][essential_fields][value][]" value="<?php echo e($essentialField['name_value']); ?>" class="form-control">
                        </div>
                    </div>
                </div>

                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="form-group">
                <label class="required">
                    <?php echo app('translator')->get('messages.value'); ?>
                </label>
                <input type="text" name="essential_fields[description]" value="" class="form-control">
                <div class="col-md-1 mt-auto mb-auto">
                    <div class="form-group">
                        <button type="button" class="btn btn-danger btn-sm float-right delete_request_body_row">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>


<div class="row">
    <div class="col-md-5">
        <?php if($project->custom_fields): ?>
        <?php $__currentLoopData = $project->custom_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if(isset($customField['enabled']) && $customField['enabled'] === "1"): ?>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="required">
                                <?php echo app('translator')->get('messages.key'); ?>
                            </label>
                            <input type="text" name="api[<?php echo e($webhook_key); ?>][request_body][<?php echo e($rb_key); ?>][key]" value="<?php echo e($customField['name_key']); ?>" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="required">
                                <?php echo app('translator')->get('messages.value'); ?>
                            </label>
                            <input type="text" name="api[<?php echo e($webhook_key); ?>][request_body][<?php echo e($rb_key); ?>][value][]" value="<?php echo e($customField['name_value']); ?>" class="form-control">
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>

        <?php endif; ?>
    </div>
</div>



<div class="row">
    <div class="col-md-5">
        <?php if($project->sales_fields): ?>
        <?php $__currentLoopData = $project->sales_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $salesField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($salesField['enabled']) && $salesField['enabled'] === "1"): ?>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="required">
                                <?php echo app('translator')->get('messages.key'); ?>
                            </label>
                            <input type="text" name="api[<?php echo e($webhook_key); ?>][request_body][<?php echo e($rb_key); ?>][key]" value="<?php echo e($salesField['name_key']); ?>" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="required">
                                <?php echo app('translator')->get('messages.value'); ?>
                            </label>
                            <input type="text" name="api[<?php echo e($webhook_key); ?>][request_body][<?php echo e($rb_key); ?>][value][]" value="<?php echo e($salesField['name_value']); ?>" class="form-control">
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>

        <?php endif; ?>
    </div>
</div>


<div class="row">
    <div class="col-md-5">
        <?php if($project->essential_fields): ?>
        <?php $__currentLoopData = $project->system_fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $systemField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(isset($systemField['enabled']) && $systemField['enabled'] === "1"): ?>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="required">
                                <?php echo app('translator')->get('messages.key'); ?>
                            </label>
                            <input type="text" name="api[<?php echo e($webhook_key); ?>][request_body][<?php echo e($rb_key); ?>][key]" value="<?php echo e($systemField['name_key']); ?>" class="form-control">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="required">
                                <?php echo app('translator')->get('messages.value'); ?>
                            </label>
                            <input type="text" name="api[<?php echo e($webhook_key); ?>][request_body][<?php echo e($rb_key); ?>][value][]" value="<?php echo e($systemField['name_value']); ?>" class="form-control">
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>

        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\laragon\www\lms_bbc-main\resources\views/admin/projects/partials/request_body_input.blade.php ENDPATH**/ ?>