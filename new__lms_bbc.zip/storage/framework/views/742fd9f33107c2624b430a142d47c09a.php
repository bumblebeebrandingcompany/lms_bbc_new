<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Create Stage</h2>
        <div class="card card-primary card-outline">
            <div class="card-body">
                
                <form method="POST" action="<?php echo e(route('admin.stages.store')); ?>" enctype="multipart/form-data"
                    class="my-custom-form">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="parent_stage_id">Parent Stage:</label>
                                <select name="parent_stage_id" id="parent_stage_id" class="form-control" required>
                                    <?php $__currentLoopData = $parentStages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentStage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($parentStage->id); ?>"><?php echo e($parentStage->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="selected_child_stages">Select Child Stages:</label>
                                <select name="selected_child_stages[]" id="selected_child_stages"
                                    class="form-control select2" multiple required
                                    data-minimum-results-for-search="Infinity">

                                    <?php $__currentLoopData = $parentStages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childStage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($childStage->id); ?>"><?php echo e($childStage->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-2 d-flex align-items-end">
                            <div class="form-group">
                                <button class="btn btn-danger" type="submit">
                                    <?php echo e(trans('global.save')); ?>

                                </button>
                            </div>
                        </div>


                    </div>
                </form>

                
                <h3>All Created Stages</h3>
                <table class="table table-bordered table-striped table-hover datatable datatable-Project">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Parent Stage</th>
                            <th>Selected Child Stages</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $counter = 1;
                        ?>
                        <?php $__currentLoopData = $stages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($counter++); ?></td>
                                <td><?php echo e($stage->parentStage->name); ?></td>
                                <td>
                                    <?php $__currentLoopData = json_decode($stage->selected_child_stages); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childStageId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($parentStages->firstWhere('id', $childStageId)->name); ?>,
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                    
                                    <button class="btn btn-sm btn-primary" data-toggle="modal"
                                        data-target="#editStageModal<?php echo e($stage->id); ?>">Edit</button>
                                    
                                    <button class="btn btn-sm btn-danger" data-toggle="modal"
                                        data-target="#deleteStageModal<?php echo e($stage->id); ?>">Delete</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <?php $__currentLoopData = $stages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="editStageModal<?php echo e($stage->id); ?>" tabindex="-1" role="dialog"
            aria-labelledby="editStageModalLabel<?php echo e($stage->id); ?>" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editStageModalLabel<?php echo e($stage->id); ?>">Edit Stage</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        
                        <form method="POST" action="<?php echo e(route('admin.stages.update', $stage->id)); ?>"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <!-- Add your form fields for editing here -->
                            <div class="form-group">
                                <label for="parent_stage_id">Edited Parent Stage:</label>
                                <select name="parent_stage_id" id="parent_stage_id" class="form-control" required>
                                    <?php $__currentLoopData = $parentStages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentStage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($parentStage->id); ?>"
                                            <?php echo e($parentStage->id == $stage->parent_stage_id ? 'selected' : ''); ?>>
                                            <?php echo e($parentStage->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <!-- Add other fields as needed -->
                            <div class="form-group">
                                <label for="selected_child_stages">Edited Child Stages:</label>
                                <select name="selected_child_stages[]" id="selected_child_stages"
                                    class="form-control select2" multiple required
                                    data-minimum-results-for-search="Infinity">

                                    <?php $__currentLoopData = $parentStages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childStage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($childStage->id); ?>"
                                            <?php echo e(in_array($childStage->id, json_decode($stage->selected_child_stages)) ? 'selected' : ''); ?>>
                                            <?php echo e($childStage->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">Save Changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $stages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="deleteStageModal<?php echo e($stage->id); ?>" tabindex="-1" role="dialog"
        aria-labelledby="deleteStageModalLabel<?php echo e($stage->id); ?>" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteStageModalLabel<?php echo e($stage->id); ?>">Delete Stage</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete this stage?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <form action="<?php echo e(route('admin.stages.destroy', $stage->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\new__lms_bbc\resources\views/admin/stages/index.blade.php ENDPATH**/ ?>