<?php $__env->startSection('content'); ?>
<div class="row mb-2">
   <div class="col-sm-12">
        <h2>
            <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.source.title')); ?>

        </h2>
   </div>
</div>
<div class="card card-primary card-outline">
    <div class="card-header">
        <a class="btn btn-default float-right" href="<?php echo e(route('admin.sources.index')); ?>">
            <?php echo e(trans('global.back_to_list')); ?>

        </a>
    </div>
    <div class="card-body">
        <div class="form-group">
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.source.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($source->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.source.fields.project')); ?>

                        </th>
                        <td>
                            <?php echo e($source->project->name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.source.fields.campaign')); ?>

                        </th>
                        <td>
                            <?php echo e($source->campaign->campaign_name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.source.fields.name')); ?>

                        </th>
                        <td>
                            <?php echo e($source->name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('messages.source_name')); ?>

                            <i class="fas fa-info-circle" data-html="true" 
                                data-toggle="tooltip" 
                                title="<?php echo e(trans('messages.source_name_help_text')); ?>">
                            </i>
                        </th>
                        <td>
                            <?php echo e($source->source_name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('messages.source_field', ['num' => 1])); ?>

                            <i class="fas fa-info-circle" data-html="true" 
                                data-toggle="tooltip" 
                                title="<?php echo e(trans('messages.source_custom_field_help_text', ['num' => 1])); ?>">
                            </i>
                        </th>
                        <td>
                            <?php echo e($source->source_field1 ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('messages.source_field', ['num' => 2])); ?>

                            <i class="fas fa-info-circle" data-html="true" 
                                data-toggle="tooltip" 
                                title="<?php echo e(trans('messages.source_custom_field_help_text', ['num' => 2])); ?>">
                            </i>
                        </th>
                        <td>
                            <?php echo e($source->source_field2 ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('messages.source_field', ['num' => 3])); ?>

                            <i class="fas fa-info-circle" data-html="true" 
                                data-toggle="tooltip" 
                                title="<?php echo e(trans('messages.source_custom_field_help_text', ['num' => 3])); ?>">
                            </i>
                        </th>
                        <td>
                            <?php echo e($source->source_field3 ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('messages.source_field', ['num' => 4])); ?>

                            <i class="fas fa-info-circle" data-html="true" 
                                data-toggle="tooltip" 
                                title="<?php echo e(trans('messages.source_custom_field_help_text', ['num' => 4])); ?>">
                            </i>
                        </th>
                        <td>
                            <?php echo e($source->source_field4 ?? ''); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lms_bbc-main\resources\views/admin/sources/show.blade.php ENDPATH**/ ?>